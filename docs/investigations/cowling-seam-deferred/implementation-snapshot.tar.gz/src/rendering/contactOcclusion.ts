import {
  DepthFormat,
  DepthTexture,
  DirectionalLight,
  Line,
  MeshBasicMaterial,
  MeshLambertMaterial,
  MeshPhongMaterial,
  Material,
  Mesh,
  Matrix4,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  MeshToonMaterial,
  NearestFilter,
  OrthographicCamera,
  Object3D,
  Points,
  RenderTarget,
  Sprite,
  Texture,
  UnsignedIntType,
  type Camera,
  type Scene,
} from 'three'
import {
  MeshLambertNodeMaterial,
  MeshPhongNodeMaterial,
  MeshPhysicalNodeMaterial,
  MeshStandardNodeMaterial,
  MeshToonNodeMaterial,
  WebGPURenderer,
  type Node,
  type UniformNode,
} from 'three/webgpu'
import {
  Fn,
  If,
  float,
  positionWorld,
  renderGroup,
  texture,
  uniform,
  vec2,
  vec4,
} from 'three/tsl'
import type { AppRenderer } from './createAppRenderer'

export interface ContactOcclusionStatus {
  readonly supported: boolean
  readonly enabled: boolean
  readonly reason: string | null
  readonly unsupportedSurfaceCount: number
  readonly surfaceDiagnostics: ContactOcclusionSurfaceDiagnostics
  readonly lightSpaceMap: {
    readonly resolution: number
    /** Orthographic world-space width and height represented by each depth texel. */
    readonly texelWorldSizeM: readonly [number, number] | null
  }
}

export interface ContactOcclusionSurfaceDiagnostics {
  /** Visible depth-writing surfaces that also pass the active camera's layer mask. */
  readonly visibleDepthWritingSurfaceCount: number
  /** Counts each unsupported eligible surface once, under its first matching reason. */
  readonly unsupportedReasonCounts: Readonly<Record<ContactOcclusionUnsupportedReason, number>>
  /** Counts visible depth-writing camera-layer meshes only. */
  readonly shadowFlags: {
    readonly eligibleMeshes: number
    readonly castShadowMeshes: number
    readonly receiveShadowMeshes: number
  }
  /** Counts eligible node material classes and lighting hook state. */
  readonly nodeMaterials: ContactOcclusionNodeMaterialDiagnostics
}

export interface ContactOcclusionNodeMaterialDiagnostics {
  readonly materialCount: number
  readonly classes: {
    readonly standard: number
    readonly physical: number
    readonly phong: number
    readonly lambert: number
    readonly toon: number
    readonly other: number
  }
  readonly hookOverrides: {
    readonly lightingModel: number
    readonly shader: number
  }
}

export type ContactOcclusionUnsupportedReason =
  | 'non-mesh-surface'
  | 'render-callback'
  | 'custom-depth-material'
  | 'transparent-material'
  | 'alpha-to-coverage-material'
  | 'custom-shader-material'
  | 'node-material'
  | 'unsupported-material'

export interface ContactOcclusionControl {
  readonly getStatus: () => ContactOcclusionStatus
  readonly setEnabled: (enabled: boolean) => ContactOcclusionStatus
  readonly registerLightingMaterial: (material: Material) => void
  readonly renderDepthPrepass: () => void
  readonly dispose: () => void
}

type CoverageMaterial = Material & {
  readonly map?: Texture | null
  readonly alphaMap?: Texture | null
  readonly displacementMap?: Texture | null
  readonly displacementScale?: number
  readonly displacementBias?: number
  readonly wireframe?: boolean
  readonly wireframeLinewidth?: number
}

type ContactMesh = Mesh & {
  material: Material | Material[]
  customDepthMaterial?: Material | null
}

// Fixed candidate resolution; status reports the resulting world-space texel pitch.
const CONTACT_DEPTH_MAP_RESOLUTION = 2048
// The opt-in candidate failed visual and performance validation.
const CONTACT_OCCLUSION_VALIDATED: boolean = false
const EMPTY_SURFACE_DIAGNOSTICS: ContactOcclusionSurfaceDiagnostics = {
  visibleDepthWritingSurfaceCount: 0,
  unsupportedReasonCounts: {
    'non-mesh-surface': 0,
    'render-callback': 0,
    'custom-depth-material': 0,
    'transparent-material': 0,
    'alpha-to-coverage-material': 0,
    'custom-shader-material': 0,
    'node-material': 0,
    'unsupported-material': 0,
  },
  shadowFlags: {
    eligibleMeshes: 0,
    castShadowMeshes: 0,
    receiveShadowMeshes: 0,
  },
  nodeMaterials: {
    materialCount: 0,
    classes: { standard: 0, physical: 0, phong: 0, lambert: 0, toon: 0, other: 0 },
    hookOverrides: { lightingModel: 0, shader: 0 },
  },
}

/** Installs a default-off light-space key-light occlusion pass. */
export function createContactOcclusionControl(
  renderer: AppRenderer,
  scene: Scene,
  camera: Camera,
  keyLight: DirectionalLight | null,
  requestedAtStartup: boolean,
  reversedDepthBuffer = camera.reversedDepth,
  prepareContactCamera?: () => void,
): ContactOcclusionControl {
  if (!CONTACT_OCCLUSION_VALIDATED || !(renderer instanceof WebGPURenderer) || keyLight == null) {
    const reason = !CONTACT_OCCLUSION_VALIDATED
      ? 'Contact occlusion is disabled: the depth pass produced shadow stripes and unacceptable rendering cost.'
      : keyLight == null
        ? 'Contact occlusion requires the selected directional light.'
        : 'Contact occlusion requires the WebGPU renderer.'
    const status: ContactOcclusionStatus = {
      supported: false,
      enabled: false,
      reason,
      unsupportedSurfaceCount: 0,
      surfaceDiagnostics: EMPTY_SURFACE_DIAGNOSTICS,
      lightSpaceMap: { resolution: CONTACT_DEPTH_MAP_RESOLUTION, texelWorldSizeM: null },
    }
    return {
      getStatus: () => status,
      setEnabled: () => status,
      registerLightingMaterial: () => {},
      renderDepthPrepass: () => {},
      dispose: () => {},
    }
  }

  const depthTexture = new DepthTexture(1, 1, UnsignedIntType)
  depthTexture.name = 'contact-occlusion-depth'
  depthTexture.format = DepthFormat
  depthTexture.type = UnsignedIntType
  depthTexture.minFilter = NearestFilter
  depthTexture.magFilter = NearestFilter
  depthTexture.generateMipmaps = false
  depthTexture.compareFunction = null

  const target = new RenderTarget(1, 1, {
    depthBuffer: true,
    stencilBuffer: false,
  })
  target.samples = 0
  target.depthTexture = depthTexture

  const lightCamera = keyLight.shadow.camera as OrthographicCamera
  const enabled = uniform(0).setGroup(renderGroup).setName('contactOcclusionEnabled')
  const lightViewMatrix = uniform(new Matrix4())
    .setGroup(renderGroup)
    .setName('contactOcclusionLightViewMatrix')
  const lightProjectionMatrix = uniform(new Matrix4())
    .setGroup(renderGroup)
    .setName('contactOcclusionLightProjectionMatrix')
  const lightDepthSpanM = uniform(1)
    .setGroup(renderGroup)
    .setName('contactOcclusionLightDepthSpanM')
  const minimumContactGapM = uniform(0)
    .setGroup(renderGroup)
    .setName('contactOcclusionMinimumGapM')
  const depthNode = texture(depthTexture)
  const occlusionFactor = createOcclusionFactor(
    depthNode,
    lightViewMatrix,
    lightProjectionMatrix,
    lightDepthSpanM,
    minimumContactGapM,
    enabled,
    reversedDepthBuffer,
  )
  const library = renderer.library
  const hadOwnFromMaterial = Object.hasOwn(library, 'fromMaterial')
  const previousFromMaterial = library.fromMaterial
  const callPreviousFromMaterial = previousFromMaterial.bind(library)
  type ContactLightingNodeMaterial =
    | MeshStandardNodeMaterial
    | MeshPhysicalNodeMaterial
    | MeshPhongNodeMaterial
    | MeshLambertNodeMaterial
    | MeshToonNodeMaterial
  const lightingHooks = new WeakMap<Material, {
    readonly isInstalled: () => boolean
    readonly restore: () => void
  }>()
  const hasLightingHook = (material: Material): boolean => lightingHooks.get(material)?.isInstalled() ?? false
  const hookedLightingMaterials = new Set<Material>()
  const installLightingHook = (material: ContactLightingNodeMaterial): void => {
    if (lightingHooks.has(material)) return

    const ownSetupLightingModel = Object.getOwnPropertyDescriptor(material, 'setupLightingModel')
    const ownCustomProgramCacheKey = Object.getOwnPropertyDescriptor(material, 'customProgramCacheKey')
    const setupLightingModel = material.setupLightingModel.bind(material)
    const customProgramCacheKey = material.customProgramCacheKey.bind(material)
    const wrappedSetupLightingModel = function () {
      const lightingModel = setupLightingModel()
      if (lightingModel == null) return lightingModel

      const direct = lightingModel.direct.bind(lightingModel)
      lightingModel.direct = (input, builder) => {
        const lightNode = input.lightNode as Node & { readonly light?: DirectionalLight | null }
        if (lightNode.light !== keyLight || !builder.object.receiveShadow) {
          direct(input, builder)
          return
        }

        const originalLightColor = input.lightColor
        input.lightColor = input.lightColor.mul(occlusionFactor)
        try {
          direct(input, builder)
        } finally {
          input.lightColor = originalLightColor
        }
      }
      return lightingModel
    }

    const wrappedCustomProgramCacheKey = () => `${customProgramCacheKey()}|contact-occlusion-key-light-v1`
    material.setupLightingModel = wrappedSetupLightingModel
    material.customProgramCacheKey = wrappedCustomProgramCacheKey
    material.needsUpdate = true
    const restore = () => {
      let restored = false
      if (material.setupLightingModel === wrappedSetupLightingModel) {
        if (ownSetupLightingModel == null) {
          Reflect.deleteProperty(material, 'setupLightingModel')
        } else {
          Object.defineProperty(material, 'setupLightingModel', ownSetupLightingModel)
        }
        restored = true
      }
      if (material.customProgramCacheKey === wrappedCustomProgramCacheKey) {
        if (ownCustomProgramCacheKey == null) {
          Reflect.deleteProperty(material, 'customProgramCacheKey')
        } else {
          Object.defineProperty(material, 'customProgramCacheKey', ownCustomProgramCacheKey)
        }
        restored = true
      }
      if (restored) material.needsUpdate = true
    }
    lightingHooks.set(material, {
      isInstalled: () => material.setupLightingModel === wrappedSetupLightingModel &&
        material.customProgramCacheKey === wrappedCustomProgramCacheKey,
      restore,
    })
    hookedLightingMaterials.add(material)
  }
  const wrappedFromMaterial = (material: Material) => {
    const converted = callPreviousFromMaterial(material)
    if (converted == null) return converted

    if (isNodeMaterial(material)) {
      if (!isSupportedCoverageSafeNodeMaterial(material, hasLightingHook(material))) return converted
      installLightingHook(material)
      if (
        converted !== material &&
        isSupportedCoverageSafeNodeMaterial(converted, hasLightingHook(converted))
      ) {
        installLightingHook(converted)
      }
      return converted
    }

    if (isSupportedCoverageSafeNodeMaterial(converted)) installLightingHook(converted)
    return converted
  }
  library.fromMaterial = wrappedFromMaterial

  const depthMaterials = new WeakMap<Material, {
    readonly casting: MeshStandardNodeMaterial
    readonly nonCasting: MeshStandardNodeMaterial
  }>()
  let isEnabled = false
  let reason: string | null = null
  let unsupportedSurfaceCount = 0
  let surfaceDiagnostics = EMPTY_SURFACE_DIAGNOSTICS
  enabled.value = requestedAtStartup ? 1 : 0
  isEnabled = requestedAtStartup

  const inspectSupport = (): void => {
    const inspection = inspectContactOcclusionSurfaces(
      scene,
      camera,
      hasLightingHook,
    )
    unsupportedSurfaceCount = inspection.unsupportedSurfaceCount
    surfaceDiagnostics = inspection.surfaceDiagnostics
    reason = scene.overrideMaterial != null
      ? 'A scene override material prevents matching the visible surface coverage.'
      : unsupportedSurfaceCount > 0
        ? 'Visible custom or non-mesh surfaces prevent a matching depth prepass.'
        : prepareContactCamera == null
          ? 'Contact occlusion requires the fitted directional-light camera.'
          : !(lightCamera instanceof OrthographicCamera)
            ? 'Contact occlusion requires an orthographic directional-light camera.'
            : null
  }

  const getLightSpaceMap = (): ContactOcclusionStatus['lightSpaceMap'] => ({
    resolution: CONTACT_DEPTH_MAP_RESOLUTION,
    texelWorldSizeM: lightCamera instanceof OrthographicCamera
      ? [
          (lightCamera.right - lightCamera.left) / CONTACT_DEPTH_MAP_RESOLUTION,
          (lightCamera.top - lightCamera.bottom) / CONTACT_DEPTH_MAP_RESOLUTION,
        ]
      : null,
  })

  const makeStatus = (): ContactOcclusionStatus => ({
    supported: reason == null,
    enabled: isEnabled && reason == null,
    reason,
    unsupportedSurfaceCount,
    surfaceDiagnostics,
    lightSpaceMap: getLightSpaceMap(),
  })

  const getStatus = (): ContactOcclusionStatus => {
    inspectSupport()
    return makeStatus()
  }

  const setEnabled = (nextEnabled: boolean): ContactOcclusionStatus => {
    isEnabled = nextEnabled
    inspectSupport()
    if (nextEnabled && reason != null) {
      isEnabled = false
    }
    enabled.value = isEnabled ? 1 : 0
    return makeStatus()
  }

  const renderDepthPrepass = (): void => {
    if (!isEnabled) return
    inspectSupport()
    if (reason != null) {
      isEnabled = false
      enabled.value = 0
      return
    }

    prepareContactCamera?.()
    const depthSpan = lightCamera.far - lightCamera.near
    if (!Number.isFinite(depthSpan) || depthSpan <= 0) {
      isEnabled = false
      enabled.value = 0
      reason = 'The directional-light camera has no usable depth range.'
      return
    }
    lightDepthSpanM.value = depthSpan
    // Match Three's normalized depth bias in world units.
    minimumContactGapM.value = Math.max(0, -keyLight.shadow.bias * depthSpan)
    // Sample the actual receiver position without normalBias.
    if (target.width !== CONTACT_DEPTH_MAP_RESOLUTION || target.height !== CONTACT_DEPTH_MAP_RESOLUTION) {
      target.setSize(CONTACT_DEPTH_MAP_RESOLUTION, CONTACT_DEPTH_MAP_RESOLUTION)
    }

    const originalTarget = renderer.getRenderTarget()
    const originalAutoClear = renderer.autoClear
    const originalAutoClearDepth = renderer.autoClearDepth
    const originalAutoClearColor = renderer.autoClearColor
    const originalOverrideMaterial = scene.overrideMaterial
    const originalLightCameraLayerMask = lightCamera.layers.mask
    const originalMeshMaterials = new Map<ContactMesh, Material | Material[]>()

    try {
      scene.traverseVisible(object => {
        if (!(object instanceof Mesh)) return
        const mesh = object as ContactMesh
        originalMeshMaterials.set(mesh, mesh.material)
        mesh.material = mapMaterials(mesh.material, material => {
          const depthMaterial = getDepthMaterial(material, mesh.castShadow, depthMaterials)
          syncDepthMaterial(material, depthMaterial)
          depthMaterial.visible = mesh.castShadow && depthMaterial.visible
          return depthMaterial
        })
      })

      scene.overrideMaterial = null
      lightCamera.layers.mask = camera.layers.mask
      renderer.setRenderTarget(target)
      renderer.autoClear = true
      renderer.autoClearDepth = true
      renderer.autoClearColor = false
      renderer.render(scene, lightCamera)
      // Renderer synchronizes reversed depth and coordinate-system state on the camera.
      lightViewMatrix.value.copy(lightCamera.matrixWorldInverse)
      lightProjectionMatrix.value.copy(lightCamera.projectionMatrix)
    } finally {
      for (const [mesh, material] of originalMeshMaterials) {
        mesh.material = material
      }
      scene.overrideMaterial = originalOverrideMaterial
      lightCamera.layers.mask = originalLightCameraLayerMask
      renderer.setRenderTarget(originalTarget)
      renderer.autoClear = originalAutoClear
      renderer.autoClearDepth = originalAutoClearDepth
      renderer.autoClearColor = originalAutoClearColor
    }
  }

  return {
    getStatus,
    setEnabled,
    registerLightingMaterial: material => {
      // The deferred renderer owns these resolve materials and their G-buffer coverage.
      if (isSupportedLightingNodeMaterial(material)) installLightingHook(material)
    },
    renderDepthPrepass,
    dispose: () => {
      target.dispose()
      if (library.fromMaterial === wrappedFromMaterial) {
        if (hadOwnFromMaterial) {
          library.fromMaterial = previousFromMaterial
        } else {
          delete (library as { fromMaterial?: typeof library.fromMaterial }).fromMaterial
        }
      }
      for (const material of hookedLightingMaterials) {
        lightingHooks.get(material)?.restore()
      }
      hookedLightingMaterials.clear()
    },
  }
}

export function isContactOcclusionRequested(searchParams: URLSearchParams): boolean {
  const requested = searchParams.get('contactOcclusion')?.trim().toLowerCase()
  return requested === '1' || requested === 'true' || requested === 'yes' || requested === 'on'
}

function createOcclusionFactor(
  depthNode: ReturnType<typeof texture>,
  lightViewMatrix: UniformNode<Matrix4>,
  lightProjectionMatrix: UniformNode<Matrix4>,
  lightDepthSpanM: UniformNode<number>,
  minimumContactGapM: UniformNode<number>,
  enabled: UniformNode<number>,
  reversedDepth: boolean,
): Node {
  return Fn(() => {
    const occluded = float(0).toVar()
    If(enabled.greaterThan(0), () => {
      const clipPosition = lightProjectionMatrix
        .mul(lightViewMatrix)
        .mul(vec4(positionWorld, 1))
      const ndc = clipPosition.xyz.div(clipPosition.w)
      const uv = vec2(
        ndc.x.mul(0.5).add(0.5),
        float(0.5).sub(ndc.y.mul(0.5)),
      )
      const inBounds = clipPosition.w.greaterThan(0)
        .and(uv.x.greaterThan(0).and(uv.x.lessThan(1)))
        .and(uv.y.greaterThan(0).and(uv.y.lessThan(1)))
        .and(ndc.z.greaterThan(0).and(ndc.z.lessThan(1)))
      const casterDepth = depthNode.sample(uv).r
      const depthGap = reversedDepth
        ? casterDepth.sub(ndc.z)
        : ndc.z.sub(casterDepth)
      const worldGap = depthGap.mul(lightDepthSpanM)
      const occludingCaster = worldGap.greaterThan(minimumContactGapM)
      If(inBounds.and(occludingCaster), () => {
        occluded.assign(float(1))
      })
    })
    return float(1).sub(occluded)
  }, 'float')()
}

/** Reports supported light-space coverage and surface diagnostics in one traversal. */
function inspectContactOcclusionSurfaces(
  scene: Scene,
  camera: Camera,
  hasContactLightingHook: (material: Material) => boolean,
): {
  readonly unsupportedSurfaceCount: number
  readonly surfaceDiagnostics: ContactOcclusionSurfaceDiagnostics
} {
  const unsupportedReasonCounts: Record<ContactOcclusionUnsupportedReason, number> = {
    'non-mesh-surface': 0,
    'render-callback': 0,
    'custom-depth-material': 0,
    'transparent-material': 0,
    'alpha-to-coverage-material': 0,
    'custom-shader-material': 0,
    'node-material': 0,
    'unsupported-material': 0,
  }
  const nodeMaterialDiagnostics = {
    materialCount: 0,
    classes: { standard: 0, physical: 0, phong: 0, lambert: 0, toon: 0, other: 0 },
    hookOverrides: { lightingModel: 0, shader: 0 },
  }
  let visibleDepthWritingSurfaceCount = 0
  let eligibleMeshes = 0
  let castShadowMeshes = 0
  let receiveShadowMeshes = 0
  let unsupportedSurfaceCount = scene.overrideMaterial == null ? 0 : 1

  scene.traverseVisible(object => {
    if (
      scene.overrideMaterial == null &&
      isLegacyUnsupportedSurface(object, hasContactLightingHook)
    ) {
      unsupportedSurfaceCount += 1
    }

    if (!camera.layers.test(object.layers)) return
    if (!(object instanceof Mesh || object instanceof Points || object instanceof Line || object instanceof Sprite)) return

    const materials = Array.isArray(object.material) ? object.material : [object.material]
    const visibleDepthMaterials = materials.filter(material => material.visible && material.depthWrite)
    if (visibleDepthMaterials.length === 0) return

    visibleDepthWritingSurfaceCount += 1
    inspectNodeMaterials(visibleDepthMaterials, nodeMaterialDiagnostics)
    if (object instanceof Mesh) {
      eligibleMeshes += 1
      if (object.castShadow) castShadowMeshes += 1
      if (object.receiveShadow) receiveShadowMeshes += 1
    }

    const reason = getUnsupportedSurfaceReason(object, visibleDepthMaterials, hasContactLightingHook)
    if (reason != null) unsupportedReasonCounts[reason] += 1
  })

  return {
    unsupportedSurfaceCount,
    surfaceDiagnostics: {
      visibleDepthWritingSurfaceCount,
      unsupportedReasonCounts,
      shadowFlags: { eligibleMeshes, castShadowMeshes, receiveShadowMeshes },
      nodeMaterials: nodeMaterialDiagnostics,
    },
  }
}

function inspectNodeMaterials(
  materials: readonly Material[],
  diagnostics: {
    materialCount: number
    classes: Record<'standard' | 'physical' | 'phong' | 'lambert' | 'toon' | 'other', number>
    hookOverrides: Record<'lightingModel' | 'shader', number>
  },
): void {
  for (const material of materials) {
    if (!isNodeMaterial(material)) continue

    diagnostics.materialCount += 1
    const prototype = getContactNodeMaterialPrototype(material)
    if (material.constructor === MeshPhysicalNodeMaterial) diagnostics.classes.physical += 1
    else if (material.constructor === MeshStandardNodeMaterial) diagnostics.classes.standard += 1
    else if (material.constructor === MeshPhongNodeMaterial) diagnostics.classes.phong += 1
    else if (material.constructor === MeshLambertNodeMaterial) diagnostics.classes.lambert += 1
    else if (material.constructor === MeshToonNodeMaterial) diagnostics.classes.toon += 1
    else diagnostics.classes.other += 1

    if (prototype == null) continue
    const nodeMaterial = material as ContactNodeMaterial
    if (nodeMaterial.setupLightingModel !== prototype.setupLightingModel) {
      diagnostics.hookOverrides.lightingModel += 1
    }
    if (
      nodeMaterial.onBeforeCompile !== prototype.onBeforeCompile ||
      nodeMaterial.customProgramCacheKey !== prototype.customProgramCacheKey
    ) {
      diagnostics.hookOverrides.shader += 1
    }
  }
}

function isLegacyUnsupportedSurface(
  object: Object3D,
  hasContactLightingHook: (material: Material) => boolean,
): boolean {
  if (
    object.onBeforeRender !== Object3D.prototype.onBeforeRender ||
    object.onBeforeShadow !== Object3D.prototype.onBeforeShadow
  ) return true
  if (object instanceof Points || object instanceof Line || object instanceof Sprite) {
    const materials = Array.isArray(object.material) ? object.material : [object.material]
    return materials.some(material => material.visible && material.depthWrite)
  }
  if (!(object instanceof Mesh)) return false

  const mesh = object as ContactMesh
  if (mesh.customDepthMaterial != null) return true
  const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
  return materials.some(material => isUnsupportedMaterial(material, hasContactLightingHook))
}

function getUnsupportedSurfaceReason(
  object: Mesh | Points | Line | Sprite,
  materials: readonly Material[],
  hasContactLightingHook: (material: Material) => boolean,
): ContactOcclusionUnsupportedReason | null {
  if (!(object instanceof Mesh)) return 'non-mesh-surface'
  if (
    object.onBeforeRender !== Object3D.prototype.onBeforeRender ||
    object.onBeforeShadow !== Object3D.prototype.onBeforeShadow
  ) return 'render-callback'

  const mesh = object as ContactMesh
  if (mesh.customDepthMaterial != null) return 'custom-depth-material'
  if (materials.some(material => material.transparent)) return 'transparent-material'
  if (materials.some(material => material.alphaToCoverage)) return 'alpha-to-coverage-material'
  if (materials.some(material =>
    isNodeMaterial(material) &&
    !isSupportedCoverageSafeNodeMaterial(material, hasContactLightingHook(material))
  )) {
    return 'node-material'
  }
  if (materials.some(material => !isNodeMaterial(material) && hasCustomShaderHooks(material))) {
    return 'custom-shader-material'
  }
  if (materials.some(material =>
    isNodeMaterial(material)
      ? !isSupportedCoverageSafeNodeMaterial(material, hasContactLightingHook(material))
      : !isSupportedSourceMaterial(material)
  )) return 'unsupported-material'
  return null
}

function isUnsupportedMaterial(
  material: Material,
  hasContactLightingHook: (material: Material) => boolean,
): boolean {
  if (!material.visible || !material.depthWrite) return false
  return material.transparent ||
    material.alphaToCoverage ||
    (isNodeMaterial(material)
      ? !isSupportedCoverageSafeNodeMaterial(material, hasContactLightingHook(material))
      : hasCustomShaderHooks(material) || !isSupportedSourceMaterial(material))
}

function isSupportedSourceMaterial(material: Material): boolean {
  return material.constructor === MeshStandardMaterial ||
    material.constructor === MeshPhysicalMaterial ||
    material.constructor === MeshPhongMaterial ||
    material.constructor === MeshLambertMaterial ||
    material.constructor === MeshToonMaterial ||
    material.constructor === MeshBasicMaterial
}

type ContactNodeMaterial =
  | MeshStandardNodeMaterial
  | MeshPhysicalNodeMaterial
  | MeshPhongNodeMaterial
  | MeshLambertNodeMaterial
  | MeshToonNodeMaterial

type ContactNodeMaterialPrototype =
  | typeof MeshStandardNodeMaterial.prototype
  | typeof MeshPhysicalNodeMaterial.prototype
  | typeof MeshPhongNodeMaterial.prototype
  | typeof MeshLambertNodeMaterial.prototype
  | typeof MeshToonNodeMaterial.prototype

function getContactNodeMaterialPrototype(
  material: Material,
): ContactNodeMaterialPrototype | null {
  if (material.constructor === MeshPhysicalNodeMaterial) return MeshPhysicalNodeMaterial.prototype
  if (material.constructor === MeshStandardNodeMaterial) return MeshStandardNodeMaterial.prototype
  if (material.constructor === MeshPhongNodeMaterial) return MeshPhongNodeMaterial.prototype
  if (material.constructor === MeshLambertNodeMaterial) return MeshLambertNodeMaterial.prototype
  if (material.constructor === MeshToonNodeMaterial) return MeshToonNodeMaterial.prototype
  return null
}

function isSupportedLightingNodeMaterial(material: Material): material is ContactNodeMaterial {
  return getContactNodeMaterialPrototype(material) != null
}

function isSupportedCoverageSafeNodeMaterial(
  material: Material,
  hasContactLightingHook = false,
): material is MeshStandardNodeMaterial | MeshPhysicalNodeMaterial {
  const prototype = material.constructor === MeshPhysicalNodeMaterial
    ? MeshPhysicalNodeMaterial.prototype
    : material.constructor === MeshStandardNodeMaterial
      ? MeshStandardNodeMaterial.prototype
      : null
  if (prototype == null) return false

  const node = material as MeshPhysicalNodeMaterial & { readonly maskShadowNode?: Node | null }
  // Normal, roughness, metalness, emissive, and AO nodes affect lighting only. The separate
  // depth pass uses copied base coverage fields.
  return (
    node.setupLightingModel === prototype.setupLightingModel || hasContactLightingHook
  ) &&
    node.onBeforeCompile === prototype.onBeforeCompile &&
    (node.customProgramCacheKey === prototype.customProgramCacheKey || hasContactLightingHook) &&
    node.colorNode == null &&
    node.opacityNode == null &&
    node.backdropNode == null &&
    node.backdropAlphaNode == null &&
    node.alphaTestNode == null &&
    node.maskNode == null &&
    node.maskShadowNode == null &&
    node.positionNode == null &&
    node.geometryNode == null &&
    node.depthNode == null &&
    node.receivedShadowPositionNode == null &&
    node.castShadowPositionNode == null &&
    node.receivedShadowNode == null &&
    node.castShadowNode == null &&
    node.outputNode == null &&
    node.mrtNode == null &&
    node.fragmentNode == null &&
    node.vertexNode == null &&
    node.contextNode == null &&
    node.lightsNode == null &&
    node.envNode == null &&
    node.clearcoatNode == null &&
    node.clearcoatRoughnessNode == null &&
    node.clearcoatNormalNode == null &&
    node.sheenNode == null &&
    node.sheenRoughnessNode == null &&
    node.iridescenceNode == null &&
    node.iridescenceIORNode == null &&
    node.iridescenceThicknessNode == null &&
    node.specularIntensityNode == null &&
    node.specularColorNode == null &&
    node.iorNode == null &&
    node.transmissionNode == null &&
    node.thicknessNode == null &&
    node.attenuationDistanceNode == null &&
    node.attenuationColorNode == null &&
    node.dispersionNode == null &&
    node.anisotropyNode == null
}

function hasCustomShaderHooks(material: Material): boolean {
  if (isNodeMaterial(material)) {
    const prototype = getContactNodeMaterialPrototype(material)
    if (prototype == null) return true
    const nodeMaterial = material as ContactNodeMaterial
    return nodeMaterial.onBeforeCompile !== prototype.onBeforeCompile ||
      nodeMaterial.customProgramCacheKey !== prototype.customProgramCacheKey
  }

  return material.onBeforeCompile !== Material.prototype.onBeforeCompile ||
    material.customProgramCacheKey !== Material.prototype.customProgramCacheKey
}

function isNodeMaterial(material: Material): boolean {
  return 'isNodeMaterial' in material && material.isNodeMaterial === true
}

function mapMaterials(
  materials: Material | Material[],
  mapMaterial: (material: Material) => Material,
): Material | Material[] {
  return Array.isArray(materials) ? materials.map(mapMaterial) : mapMaterial(materials)
}

function getDepthMaterial(
  source: Material,
  castShadow: boolean,
  depthMaterials: WeakMap<Material, {
    readonly casting: MeshStandardNodeMaterial
    readonly nonCasting: MeshStandardNodeMaterial
  }>,
): MeshStandardNodeMaterial {
  let variants = depthMaterials.get(source)
  if (variants == null) {
    variants = {
      casting: new MeshStandardNodeMaterial(),
      nonCasting: new MeshStandardNodeMaterial(),
    }
    depthMaterials.set(source, variants)
  }
  return castShadow ? variants.casting : variants.nonCasting
}

// WebGPU has no MeshDepthMaterial mapping. An unlit node material preserves displacement and coverage.
function syncDepthMaterial(source: Material, target: MeshStandardNodeMaterial): void {
  const coverageSource = source as CoverageMaterial
  const map = coverageSource.map ?? null
  const alphaMap = coverageSource.alphaMap ?? null
  const displacementMap = coverageSource.displacementMap ?? null
  const wireframe = coverageSource.wireframe ?? false
  const side = source.shadowSide ?? source.side
  const clippingPlaneCount = source.clippingPlanes?.length ?? 0
  const needsUpdate =
    target.vertexColors !== source.vertexColors ||
    target.side !== side ||
    (target.map != null) !== (map != null) ||
    (target.alphaMap != null) !== (alphaMap != null) ||
    (target.displacementMap != null) !== (displacementMap != null) ||
    target.wireframe !== wireframe ||
    (target.alphaTest > 0) !== (source.alphaTest > 0) ||
    target.alphaHash !== source.alphaHash ||
    (target.clippingPlanes?.length ?? 0) !== clippingPlaneCount ||
    target.clipIntersection !== source.clipIntersection

  // Material.copy() deep-serializes userData and clones clipping planes. Neither
  // belongs to this render-only material, so copy only its depth and coverage state.
  if (needsUpdate) target.needsUpdate = true
  target.vertexColors = source.vertexColors
  target.opacity = source.opacity
  target.depthFunc = source.depthFunc
  target.depthTest = source.depthTest
  target.depthWrite = source.depthWrite
  target.clippingPlanes = source.clippingPlanes
  target.clipIntersection = source.clipIntersection
  target.clipShadows = source.clipShadows
  target.polygonOffset = source.polygonOffset
  target.polygonOffsetFactor = source.polygonOffsetFactor
  target.polygonOffsetUnits = source.polygonOffsetUnits
  target.alphaTest = source.alphaTest
  target.alphaHash = source.alphaHash
  target.map = map
  target.alphaMap = alphaMap
  target.displacementMap = displacementMap
  target.displacementScale = coverageSource.displacementScale ?? 1
  target.displacementBias = coverageSource.displacementBias ?? 0
  target.wireframe = wireframe
  target.wireframeLinewidth = coverageSource.wireframeLinewidth ?? 1
  target.side = side
  target.transparent = false
  target.visible = source.visible && source.depthWrite
  target.colorWrite = false
  target.lights = false
}
