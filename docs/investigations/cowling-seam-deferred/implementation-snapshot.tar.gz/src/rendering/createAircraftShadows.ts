import {
  Box3,
  DirectionalLight,
  InstancedMesh,
  Mesh,
  MeshBasicMaterial,
  SkinnedMesh,
  Vector3,
  WebGLRenderer,
  type Camera,
  type Material,
  type Object3D,
  type OrthographicCamera,
  type Scene,
  type Texture
} from 'three'

import type { AppRenderer } from './createAppRenderer'

type MeshMaterial = Material | Material[]

type CasterMaterialState = {
  readonly material: MeshMaterial
  readonly visible: readonly boolean[]
}

type ShadowOnlyMaterials = {
  readonly source: MeshMaterial
  readonly material: MeshMaterial
}

type ShadowMaterialSource = Material & {
  readonly alphaMap?: Texture | null
  readonly map?: Texture | null
}

export interface AircraftShadows {
  setEnabled(enabled: boolean): void
  getDiagnostics(options?: ShadowInspectionOptions): AircraftShadowDiagnostics
  prepareForFrame(): void
  prepareContactCamera(): void
  renderFirstScenePass(render: () => void): void
  dispose(): void
}

export type ShadowWorldPoint = readonly [number, number, number]

function isVisibleWithinRoot(object: Object3D, root: Object3D): boolean {
  let current: Object3D | null = object
  while (current != null) {
    if (!current.visible) return false
    if (current === root) return true
    current = current.parent
  }
  return false
}

export interface ShadowInspectionOptions {
  readonly worldPoint?: ShadowWorldPoint
  readonly meshName?: string
}

export interface ShadowMeshDiagnostic {
  readonly uuid: string
  readonly name: string
  readonly type: string
  readonly visible: boolean
  readonly castShadow: boolean
  readonly receiveShadow: boolean
  readonly layersMask: number
}

export interface AircraftShadowDiagnostics {
  readonly enabled: boolean
  readonly renderer: {
    readonly type: string
    readonly backend: string | null
    readonly shadowMapEnabled: boolean
    readonly publicWebGLMapTargetPresent: boolean | null
  }
  readonly keyLight: {
    readonly uuid: string
    readonly castShadow: boolean
    readonly intensity: number
    readonly color: readonly number[]
    readonly position: readonly number[]
    readonly targetPosition: readonly number[]
    readonly bias: number
    readonly normalBias: number
    readonly radius: number
    readonly mapSize: readonly number[]
    readonly autoUpdate: boolean
    readonly needsUpdate: boolean
  }
  readonly camera: {
    readonly position: readonly number[]
    readonly near: number
    readonly far: number
    readonly left: number
    readonly right: number
    readonly top: number
    readonly bottom: number
    readonly layersMask: number
    readonly viewerCameraLayersMask: number
  }
  readonly meshes: {
    readonly total: number
    readonly visible: number
    readonly castShadow: number
    readonly receiveShadow: number
    readonly visibleCastShadow: number
    readonly visibleReceiveShadow: number
  }
  readonly meshMatches: readonly ShadowMeshDiagnostic[] | null
  readonly commonRendererHooks: {
    readonly shadowCameraPasses: number
    readonly casterMaterialSubstitutions: number
  }
  readonly worldPoint: {
    readonly position: ShadowWorldPoint
    readonly lightCameraPosition: readonly number[]
    readonly normalizedXY: readonly [number, number] | null
    readonly texelWorldSize: readonly [number, number] | null
    readonly insideFrustum: boolean
  } | null
}

/** Enables the authored model's direct-light shadows and fits them to its current world bounds. */
export function createAircraftShadows(
  renderer: AppRenderer,
  scene: Scene,
  camera: Camera,
  keyLight: DirectionalLight,
  root: Object3D
): AircraftShadows {
  const casterMaterials = new Map<Mesh, CasterMaterialState>()
  const modelMeshes: Mesh[] = []
  const shadowOnlyMaterials = new Map<Mesh, ShadowOnlyMaterials>()
  const commonShadowMaterials = new Map<Mesh, ShadowOnlyMaterials>()
  const bounds = new Box3()
  const meshBounds = new Box3()
  const projectedBounds = new Box3()
  const projectedCorner = new Vector3()
  let enabled = false
  let firstScenePassPending = false
  let commonShadowCameraPasses = 0
  let commonCasterMaterialSubstitutions = 0

  keyLight.castShadow = false
  keyLight.shadow.mapSize.set(4096, 4096)
  scene.add(keyLight.target)
  renderer.shadowMap.enabled = false

  if (renderer instanceof WebGLRenderer) {
    renderer.shadowMap.autoUpdate = false
    keyLight.shadow.autoUpdate = false
  }

  const activeCasters = new Set<Mesh>()
  const disposeMaterials = (material: MeshMaterial): void => {
    for (const entry of Array.isArray(material) ? material : [material]) entry.dispose()
  }
  const disposeCachedMaterialsForMesh = (mesh: Mesh): void => {
    const cached = shadowOnlyMaterials.get(mesh)
    if (cached != null) disposeMaterials(cached.material)
    shadowOnlyMaterials.delete(mesh)
    const commonCached = commonShadowMaterials.get(mesh)
    if (commonCached != null) disposeMaterials(commonCached.material)
    commonShadowMaterials.delete(mesh)
  }

  const disposeAllCachedMaterials = (): void => {
    for (const mesh of new Set([...shadowOnlyMaterials.keys(), ...commonShadowMaterials.keys()])) {
      disposeCachedMaterialsForMesh(mesh)
    }
  }

  const refreshCasterMaterials = (): void => {
    activeCasters.clear()
    modelMeshes.length = 0
    root.traverse(object => {
      if (!(object instanceof Mesh)) {
        return
      }
      modelMeshes.push(object)
      const material = object.material
      const materials = Array.isArray(material) ? material : [material]
      activeCasters.add(object)
      const previous = casterMaterials.get(object)
      if (previous != null && previous.material === material && previous.visible.every((visible, index) => visible === materials[index]?.visible)) return
      casterMaterials.set(object, { material, visible: materials.map(entry => entry.visible) })
    })
    for (const mesh of casterMaterials.keys()) {
      if (activeCasters.has(mesh)) continue
      casterMaterials.delete(mesh)
      disposeCachedMaterialsForMesh(mesh)
    }
  }

  const fitCameraToModel = (): void => {
    root.updateWorldMatrix(true, true)
    bounds.makeEmpty()
    for (const object of modelMeshes) {
      if (!isVisibleWithinRoot(object, root)) continue
      if (object instanceof SkinnedMesh) {
        object.computeBoundingBox()
        if (object.boundingBox == null) continue
        meshBounds.copy(object.boundingBox)
      } else if (object instanceof InstancedMesh) {
        if (object.boundingBox == null) object.computeBoundingBox()
        if (object.boundingBox == null) continue
        meshBounds.copy(object.boundingBox)
      } else {
        if (object.geometry.boundingBox == null) object.geometry.computeBoundingBox()
        if (object.geometry.boundingBox == null) continue
        meshBounds.copy(object.geometry.boundingBox)
      }
      bounds.union(meshBounds.applyMatrix4(object.matrixWorld))
    }
    if (bounds.isEmpty()) {
      return
    }

    const targetPosition = keyLight.target.getWorldPosition(new Vector3())
    const lightPosition = keyLight.getWorldPosition(new Vector3())
    const lightDirection = lightPosition.sub(targetPosition)
    if (lightDirection.lengthSq() < Number.EPSILON) {
      return
    }
    lightDirection.normalize()

    const center = bounds.getCenter(new Vector3())
    const radius = Math.max(bounds.getSize(new Vector3()).length() * 0.5, 0.5)
    const margin = Math.max(radius * 0.05, 0.25)
    const distance = radius * 2 + margin

    keyLight.target.position.copy(center)
    keyLight.position.copy(center).addScaledVector(lightDirection, distance)
    keyLight.updateWorldMatrix(true, false)
    keyLight.target.updateWorldMatrix(true, false)

    const shadowCamera = keyLight.shadow.camera
    const verticalDirection = Math.abs(lightDirection.y) > 0.98
    shadowCamera.up.set(verticalDirection ? 1 : 0, verticalDirection ? 0 : 1, 0)
    shadowCamera.position.copy(keyLight.position)
    shadowCamera.lookAt(center)
    shadowCamera.updateMatrixWorld(true)

    projectedBounds.makeEmpty()
    for (let x = 0; x < 2; x += 1) {
      for (let y = 0; y < 2; y += 1) {
        for (let z = 0; z < 2; z += 1) {
          projectedCorner.set(
            x === 0 ? bounds.min.x : bounds.max.x,
            y === 0 ? bounds.min.y : bounds.max.y,
            z === 0 ? bounds.min.z : bounds.max.z
          )
          projectedBounds.expandByPoint(projectedCorner.applyMatrix4(shadowCamera.matrixWorldInverse))
        }
      }
    }

    const projection = shadowCamera as typeof shadowCamera & {
      left: number
      right: number
      top: number
      bottom: number
    }
    projection.left = projectedBounds.min.x - margin
    projection.right = projectedBounds.max.x + margin
    projection.bottom = projectedBounds.min.y - margin
    projection.top = projectedBounds.max.y + margin
    shadowCamera.near = Math.max(0.1, distance - radius - margin)
    shadowCamera.far = distance + radius + margin
    shadowCamera.updateProjectionMatrix()
    keyLight.shadow.camera.layers.mask = camera.layers.mask
  }

  const getCommonShadowMaterials = (
    mesh: Mesh,
    state: CasterMaterialState
  ): MeshMaterial => {
    let cached = commonShadowMaterials.get(mesh)
    if (cached?.source !== state.material) {
      if (cached != null) disposeMaterials(cached.material)
      const sourceMaterials = Array.isArray(state.material) ? state.material : [state.material]
      const materials = sourceMaterials.map(() => new MeshBasicMaterial({
        colorWrite: false,
        depthWrite: true,
        depthTest: true,
      }))
      const material = Array.isArray(state.material) ? materials : materials[0]!
      cached = { source: state.material, material }
      commonShadowMaterials.set(mesh, cached)
    }

    const sourceMaterials = Array.isArray(state.material) ? state.material : [state.material]
    const shadowMaterials = (Array.isArray(cached.material) ? cached.material : [cached.material]) as MeshBasicMaterial[]
    shadowMaterials.forEach((shadowMaterial, index) => {
      const sourceMaterial = sourceMaterials[index] as ShadowMaterialSource | undefined
      if (sourceMaterial == null) {
        shadowMaterial.visible = false
        return
      }
      shadowMaterial.visible = state.visible[index] ?? sourceMaterial.visible
      shadowMaterial.side = sourceMaterial.shadowSide ?? sourceMaterial.side
      shadowMaterial.alphaTest = sourceMaterial.alphaTest
      shadowMaterial.alphaMap = sourceMaterial.alphaMap ?? null
      shadowMaterial.map = sourceMaterial.map ?? null
      shadowMaterial.transparent = sourceMaterial.transparent
      shadowMaterial.opacity = sourceMaterial.opacity
      shadowMaterial.clippingPlanes = sourceMaterial.clippingPlanes
      shadowMaterial.clipShadows = sourceMaterial.clipShadows
      shadowMaterial.needsUpdate = true
    })
    return cached.material
  }

  const getShadowOnlyMaterials = (
    mesh: Mesh,
    state: CasterMaterialState
  ): MeshMaterial => {
    let cached = shadowOnlyMaterials.get(mesh)
    if (cached?.source !== state.material) {
      if (cached != null) disposeMaterials(cached.material)
      const sourceMaterials = Array.isArray(state.material) ? state.material : [state.material]
      const clones = sourceMaterials.map(material => material.clone())
      const material = Array.isArray(state.material) ? clones : clones[0]!
      cached = { source: state.material, material }
      shadowOnlyMaterials.set(mesh, cached)
    }

    const sourceMaterials = Array.isArray(state.material) ? state.material : [state.material]
    const clones = Array.isArray(cached.material) ? cached.material : [cached.material]
    clones.forEach((clone, index) => {
      clone.copy(sourceMaterials[index]!)
      clone.visible = state.visible[index]!
      clone.colorWrite = false
      clone.depthWrite = false
    })
    return cached.material
  }

  const getDiagnostics = ({ worldPoint, meshName }: ShadowInspectionOptions = {}): AircraftShadowDiagnostics => {
    const shadowCamera = keyLight.shadow.camera as OrthographicCamera
    const horizontalSpan = shadowCamera.right - shadowCamera.left
    const verticalSpan = shadowCamera.top - shadowCamera.bottom
    let totalMeshes = 0
    let castShadowMeshes = 0
    let receiveShadowMeshes = 0
    let visibleMeshes = 0
    let visibleCastShadowMeshes = 0
    let visibleReceiveShadowMeshes = 0
    const visibleMeshMatches = meshName == null ? null : new Set<Mesh>()
    root.traverse(object => {
      if (!(object instanceof Mesh)) return
      totalMeshes += 1
      if (object.castShadow) castShadowMeshes += 1
      if (object.receiveShadow) receiveShadowMeshes += 1
    })
    root.traverseVisible(object => {
      if (!(object instanceof Mesh)) return
      visibleMeshes += 1
      if (object.castShadow) visibleCastShadowMeshes += 1
      if (object.receiveShadow) visibleReceiveShadowMeshes += 1
      if (object.name === meshName) visibleMeshMatches?.add(object)
    })

    const meshMatches: ShadowMeshDiagnostic[] | null = meshName == null ? null : []
    if (meshMatches != null) {
      root.traverse(object => {
        if (!(object instanceof Mesh) || object.name !== meshName) return
        meshMatches.push({
          uuid: object.uuid,
          name: object.name,
          type: object.type,
          visible: visibleMeshMatches?.has(object) ?? false,
          castShadow: object.castShadow,
          receiveShadow: object.receiveShadow,
          layersMask: object.layers.mask
        })
      })
    }

    const pointProjection = worldPoint == null
      ? null
      : (() => {
        const lightCameraPosition = new Vector3(...worldPoint)
          .applyMatrix4(shadowCamera.matrixWorldInverse)
        const depth = -lightCameraPosition.z
        const normalizedXY = horizontalSpan === 0 || verticalSpan === 0
          ? null
          : [
            (lightCameraPosition.x - shadowCamera.left) / horizontalSpan,
            (lightCameraPosition.y - shadowCamera.bottom) / verticalSpan
          ] as const
        const texelWorldSize = keyLight.shadow.mapSize.x === 0 || keyLight.shadow.mapSize.y === 0
          ? null
          : [
            horizontalSpan / keyLight.shadow.mapSize.x,
            verticalSpan / keyLight.shadow.mapSize.y
          ] as const
        const insideFrustum =
          lightCameraPosition.x >= shadowCamera.left &&
          lightCameraPosition.x <= shadowCamera.right &&
          lightCameraPosition.y >= shadowCamera.bottom &&
          lightCameraPosition.y <= shadowCamera.top &&
          depth >= shadowCamera.near &&
          depth <= shadowCamera.far
        return {
          position: worldPoint,
          lightCameraPosition: lightCameraPosition.toArray(),
          normalizedXY,
          texelWorldSize,
          insideFrustum
        }
      })()

    const backend = 'backend' in renderer ? renderer.backend : null
    return {
      enabled,
      renderer: {
        type: renderer.constructor.name,
        backend: backend?.constructor.name ?? null,
        shadowMapEnabled: renderer.shadowMap.enabled,
        publicWebGLMapTargetPresent: renderer instanceof WebGLRenderer
          ? keyLight.shadow.map != null
          : null
      },
      keyLight: {
        uuid: keyLight.uuid,
        castShadow: keyLight.castShadow,
        intensity: keyLight.intensity,
        color: keyLight.color.toArray(),
        position: keyLight.position.toArray(),
        targetPosition: keyLight.target.position.toArray(),
        bias: keyLight.shadow.bias,
        normalBias: keyLight.shadow.normalBias,
        radius: keyLight.shadow.radius,
        mapSize: keyLight.shadow.mapSize.toArray(),
        autoUpdate: keyLight.shadow.autoUpdate,
        needsUpdate: keyLight.shadow.needsUpdate
      },
      camera: {
        position: shadowCamera.position.toArray(),
        near: shadowCamera.near,
        far: shadowCamera.far,
        left: shadowCamera.left,
        right: shadowCamera.right,
        top: shadowCamera.top,
        bottom: shadowCamera.bottom,
        layersMask: shadowCamera.layers.mask,
        viewerCameraLayersMask: camera.layers.mask
      },
      meshes: {
        total: totalMeshes,
        visible: visibleMeshes,
        castShadow: castShadowMeshes,
        receiveShadow: receiveShadowMeshes,
        visibleCastShadow: visibleCastShadowMeshes,
        visibleReceiveShadow: visibleReceiveShadowMeshes
      },
      meshMatches,
      commonRendererHooks: {
        shadowCameraPasses: commonShadowCameraPasses,
        casterMaterialSubstitutions: commonCasterMaterialSubstitutions
      },
      worldPoint: pointProjection
    }
  }

  refreshCasterMaterials()
  fitCameraToModel()

  return {
    setEnabled(nextEnabled) {
      enabled = nextEnabled
      renderer.shadowMap.enabled = nextEnabled
      keyLight.castShadow = nextEnabled
    },
    getDiagnostics(options) {
      return getDiagnostics(options)
    },
    prepareForFrame() {
      if (!enabled) {
        firstScenePassPending = false
        return
      }
      fitCameraToModel()
      refreshCasterMaterials()
      firstScenePassPending = enabled
      if (renderer instanceof WebGLRenderer && enabled) {
        renderer.shadowMap.needsUpdate = true
        keyLight.shadow.needsUpdate = true
      }
    },
    prepareContactCamera() {
      refreshCasterMaterials()
      fitCameraToModel()
    },
    renderFirstScenePass(render) {
      if (!enabled || !firstScenePassPending) {
        render()
        return
      }
      firstScenePassPending = false

      if (!(renderer instanceof WebGLRenderer)) {
        const beforeRender = scene.onBeforeRender
        const afterRender = scene.onAfterRender
        const savedMaterials = new Map<Mesh, MeshMaterial>()
        const restore = (): void => {
          for (const [mesh, material] of savedMaterials) mesh.material = material
          savedMaterials.clear()
        }
        // Three's common renderer renders the shadow camera through this same scene.
        // Use a simple depth-writing material for that nested render so complex node
        // materials keep their normal-pass state while alpha cutout coverage remains.
        scene.onBeforeRender = function (...args) {
          beforeRender.apply(this, args)
          if (args[2] !== keyLight.shadow.camera) return
          commonShadowCameraPasses += 1
          for (const [mesh, state] of casterMaterials) {
            if (!mesh.castShadow) continue
            savedMaterials.set(mesh, mesh.material)
            mesh.material = getCommonShadowMaterials(mesh, state)
            commonCasterMaterialSubstitutions += 1
          }
        }
        scene.onAfterRender = function (...args) {
          if (args[2] === keyLight.shadow.camera) restore()
          afterRender.apply(this, args)
        }
        try {
          render()
        } finally {
          restore()
          scene.onBeforeRender = beforeRender
          scene.onAfterRender = afterRender
        }
        return
      }

      const restoreMaterials: Array<() => void> = []
      try {
        for (const [mesh, state] of casterMaterials) {
          if (!mesh.castShadow || !mesh.visible) {
            continue
          }
          const currentMaterials = Array.isArray(mesh.material) ? mesh.material : [mesh.material]
          const hasTemporaryMaterial = mesh.material !== state.material
          const hasTemporaryVisibility = state.visible.some(
            (visible, index) => currentMaterials[index]?.visible !== visible
          )
          if (!hasTemporaryMaterial && !hasTemporaryVisibility) {
            continue
          }

          const currentMaterial = mesh.material
          mesh.material = getShadowOnlyMaterials(mesh, state)
          restoreMaterials.push(() => {
            mesh.material = currentMaterial
          })
        }
        render()
      } finally {
        for (let index = restoreMaterials.length - 1; index >= 0; index -= 1) {
          restoreMaterials[index]!()
        }
      }
    },
    dispose() {
      disposeAllCachedMaterials()
      casterMaterials.clear()
      activeCasters.clear()
    }
  }
}
