import { expect, test } from 'bun:test'
import {
  BufferAttribute,
  BufferGeometry,
  Color,
  Group,
  HalfFloatType,
  LinearSRGBColorSpace,
  Mesh,
  MeshBasicMaterial,
  PerspectiveCamera,
  RenderTarget,
  Scene,
  Texture,
  Vector2,
  Vector4,
  type Camera,
  type ColorRepresentation,
} from 'three'

const gpuGlobals = globalThis as typeof globalThis & {
  GPUShaderStage?: { VERTEX: number; FRAGMENT: number; COMPUTE: number }
}
gpuGlobals.GPUShaderStage ??= { VERTEX: 1, FRAGMENT: 2, COMPUTE: 4 }

const { MeshBasicNodeMaterial, MeshStandardNodeMaterial, WebGPURenderer } = await import('three/webgpu')
const {
  canKeepBlendGBufferDecalInForwardScenePass,
  canKeepReceiverlessBlendGBufferMaterialInBasePass,
  canWriteReceiverGBufferFromProjectedGeometry,
  collectVisibleDeferredRelationships,
  configureBlendGBufferMaterialsForDecalPass,
  createMsfsRenderPasses,
  hasBlendGBufferReceiver,
  selectMsfsDecalRenderPath
} = await import('./createMsfsRenderPasses')

test('selects regular, deferred, and compatibility decal paths', () => {
  expect(selectMsfsDecalRenderPath(false, false, true)).toBe('regular')
  expect(selectMsfsDecalRenderPath(true, true, true)).toBe('deferred')
  expect(selectMsfsDecalRenderPath(true, true, false)).toBe('forward')
  expect(selectMsfsDecalRenderPath(true, false, true)).toBe('forward')
})

test('uses deferred rendering for every projected receiver set', () => {
  expect(hasBlendGBufferReceiver(0)).toBe(false)
  expect(hasBlendGBufferReceiver(1)).toBe(true)
  expect(hasBlendGBufferReceiver(3)).toBe(true)
})

test('keeps only transparent colour decals in the normal scene pass', () => {
  const transparentColour = new MeshBasicMaterial({ transparent: true })
  transparentColour.userData.gltfExtensions = {
    ASOBO_material_blend_gbuffer: { baseColorBlendFactor: 1 }
  }
  const opaqueColour = transparentColour.clone()
  opaqueColour.transparent = false
  const transparentComponent = new MeshBasicMaterial({ transparent: true })
  transparentComponent.userData.gltfExtensions = {
    ASOBO_material_blend_gbuffer: {
      baseColorBlendFactor: 0,
      emissiveBlendFactor: 0,
    }
  }

  expect(canKeepBlendGBufferDecalInForwardScenePass([transparentColour])).toBe(true)
  expect(canKeepBlendGBufferDecalInForwardScenePass([opaqueColour])).toBe(false)
  expect(canKeepBlendGBufferDecalInForwardScenePass([transparentComponent])).toBe(false)
})

test('keeps receiverless colour decals in the base pass unless draw order requires projection', () => {
  const colour = new MeshBasicMaterial({ transparent: true })
  colour.userData.gltfExtensions = {
    ASOBO_material_blend_gbuffer: { baseColorBlendFactor: 1 }
  }
  const ordered = colour.clone()
  ordered.userData.gltfExtensions = {
    ...colour.userData.gltfExtensions,
    ASOBO_material_draw_order: { drawOrderOffset: 1 }
  }
  const componentOnly = new MeshBasicMaterial({ transparent: true })
  componentOnly.userData.gltfExtensions = {
    ASOBO_material_blend_gbuffer: {
      baseColorBlendFactor: 0,
      emissiveBlendFactor: 0,
    }
  }

  expect(canKeepReceiverlessBlendGBufferMaterialInBasePass(colour)).toBe(true)
  expect(canKeepReceiverlessBlendGBufferMaterialInBasePass(ordered)).toBe(false)
  expect(canKeepReceiverlessBlendGBufferMaterialInBasePass(componentOnly)).toBe(false)
})

test('keeps native depth testing for decal occlusion', () => {
  const material = new MeshBasicMaterial()
  material.depthTest = false
  material.depthWrite = true
  material.polygonOffset = true
  configureBlendGBufferMaterialsForDecalPass([material], new Map())

  expect(material.depthTest).toBe(true)
  expect(material.depthWrite).toBe(false)
  expect(material.polygonOffset).toBe(true)
})


test('uses projected decal geometry only for constant receiver G-buffer inputs', () => {
  const material = new MeshBasicMaterial()
  expect(canWriteReceiverGBufferFromProjectedGeometry(material)).toBe(true)
  material.map = new Texture()
  expect(canWriteReceiverGBufferFromProjectedGeometry(material)).toBe(false)
  material.map = null
  ;(material as any).normalNode = {}
  expect(canWriteReceiverGBufferFromProjectedGeometry(material)).toBe(false)
})

test('limits deferred receivers to visible decals', () => {
  const receivers = new Map([
    ['visible', ['receiver-a']],
    ['hidden', ['receiver-b']],
    ['shared', ['receiver-a', 'receiver-c']],
  ])
  const active = collectVisibleDeferredRelationships(
    ['visible', 'hidden', 'shared'],
    receivers,
    decal => decal !== 'hidden'
  )

  expect(active.decals).toEqual(['visible', 'shared'])
  expect([...active.receivers]).toEqual(['receiver-a', 'receiver-c'])
})

test('skips empty deferred work and resumes it when the decal camera layer returns', () => {
  const fixture = createDeferredRenderFixture()
  fixture.camera.layers.set(2)
  const harness = createWebGpuRendererHarness()
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root
  )

  passes.render()

  expect(harness.renderCalls.length).toBe(2)
  expect(harness.renderCalls.every(call => call.target === harness.screenTarget)).toBe(true)
  expect(harness.renderCalls[1]?.autoClear).toBe(false)
  expect(harness.renderCalls[1]?.background).toBe(null)
  expect(harness.renderCalls[1]?.clearColor).toBe(0x123456)
  expect(harness.renderCalls[1]?.clearAlpha).toBe(0.25)
  expect(harness.renderCalls[1]?.cameraLayersMask).toBe(1 << 2)
  expect(fixture.camera.layers.mask).toBe(1 << 2)
  expect(harness.getCurrentTarget()).toBe(harness.screenTarget)
  expect(harness.getClearColor().getHex()).toBe(0x123456)
  expect(harness.getClearAlpha()).toBe(0.25)
  expect(harness.getAutoClear()).toBe(false)
  expect(fixture.scene.background).toBe(fixture.background)

  fixture.camera.layers.set(0)
  passes.render()

  expect(harness.renderCalls.length).toBe(7)
  expect(harness.renderCalls.slice(2).filter(call => call.target !== harness.screenTarget).length).toBe(2)
  expect(harness.renderCalls[6]?.target).toBe(harness.screenTarget)
  expect(harness.renderCalls[6]?.autoClear).toBe(false)
  expect(harness.renderCalls[6]?.background).toBe(null)
  expect(harness.renderCalls[6]?.clearColor).toBe(0x123456)
  expect(harness.renderCalls[6]?.clearAlpha).toBe(0.25)
  expect(harness.renderCalls[6]?.cameraLayersMask).toBe(1)
  expect(harness.getCurrentTarget()).toBe(harness.screenTarget)
  expect(harness.getClearColor().getHex()).toBe(0x123456)
  expect(harness.getClearAlpha()).toBe(0.25)
  expect(harness.getAutoClear()).toBe(false)
  expect(fixture.scene.background).toBe(fixture.background)
  expect(fixture.decal.material).toBe(fixture.decalMaterial)
  expect(fixture.receiver.material).toBe(fixture.receiverMaterial)
})

test('restores deferred renderer state when a G-buffer render throws', () => {
  const fixture = createDeferredRenderFixture()
  fixture.decal.visible = true
  const harness = createWebGpuRendererHarness()
  const originalCameraLayerMask = fixture.camera.layers.mask
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root
  )
  harness.throwOnRenderCall(2)

  let renderError: unknown
  try {
    passes.render()
  } catch (error) {
    renderError = error
  }
  expect(renderError instanceof Error && renderError.message === 'mock render failure').toBe(true)

  expect(harness.renderCalls[1]?.target === harness.screenTarget).toBe(false)
  expect(harness.renderCalls[1]?.autoClear).toBe(true)
  expect(harness.renderCalls[1]?.background).toBe(null)
  expect(harness.renderCalls[1]?.clearColor).toBe(0)
  expect(harness.renderCalls[1]?.clearAlpha).toBe(0)
  expect(harness.getCurrentTarget()).toBe(harness.screenTarget)
  expect(harness.getClearColor().getHex()).toBe(0x123456)
  expect(harness.getClearAlpha()).toBe(0.25)
  expect(harness.getAutoClear()).toBe(false)
  expect(fixture.camera.layers.mask).toBe(originalCameraLayerMask)
  expect(fixture.scene.background).toBe(fixture.background)
  expect(fixture.decal.material).toBe(fixture.decalMaterial)
  expect(fixture.receiver.material).toBe(fixture.receiverMaterial)
})

test('shares linear HDR output only for canvas rendering when opted in', () => {
  const fixture = createDeferredRenderFixture()
  const harness = createWebGpuRendererHarness(null)
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root,
    { sharedHdrOutputEnabled: true }
  )

  passes.render()

  const hdrTarget = harness.renderCalls[0]?.target
  expect(hdrTarget instanceof RenderTarget).toBe(true)
  expect(hdrTarget?.samples).toBe(4)
  expect(hdrTarget?.width).toBe(640)
  expect(hdrTarget?.height).toBe(360)
  expect(hdrTarget?.viewport.toArray()).toEqual([4, 6, 200, 160])
  expect(hdrTarget?.scissor.toArray()).toEqual([20, 24, 120, 80])
  expect(hdrTarget?.scissorTest).toBe(true)
  expect(harness.renderCalls.slice(0, 1).every(call => call.target === hdrTarget)).toBe(true)
  expect(harness.renderCalls.slice(1, 3).every(call => call.target !== hdrTarget)).toBe(true)
  expect(harness.renderCalls.slice(3, 5).every(call => call.target === hdrTarget)).toBe(true)
  expect(harness.renderCalls.at(-1)?.target).toBe(null)
  expect(harness.renderCalls.at(-1)?.scene === fixture.scene).toBe(false)
  expect(harness.getCurrentTarget()).toBe(null)

  let disposed = false
  hdrTarget?.addEventListener('dispose', () => { disposed = true })
  passes.dispose()
  expect(disposed).toBe(true)
})

test('keeps explicit render targets on the existing output path when shared HDR is enabled', () => {
  const fixture = createDeferredRenderFixture()
  const harness = createWebGpuRendererHarness(new RenderTarget(1, 1))
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root,
    { sharedHdrOutputEnabled: true }
  )

  passes.render()

  expect(harness.renderCalls.every(call => call.target !== null)).toBe(true)
  expect(harness.renderCalls.every(call => call.scene === fixture.scene)).toBe(true)
  expect(harness.getCurrentTarget()).toBe(harness.screenTarget)
  passes.dispose()
})

test('keeps SMAA off by default and exposes a linear-copy comparison path', () => {
  const fixture = createDeferredRenderFixture()
  const harness = createWebGpuRendererHarness(null)
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root
  )

  expect(passes.setSmaaMode('off')).toEqual({ supported: true, mode: 'off', ready: true })
  passes.render()
  expect(harness.renderCalls.some(call => call.scene !== fixture.scene)).toBe(false)

  passes.setSharedHdrOutputEnabled(true)
  expect(passes.setSmaaMode('linear-copy')).toEqual({
    supported: true,
    mode: 'linear-copy',
    ready: true,
  })
  const firstLinearCopyCall = harness.renderCalls.length
  passes.render()

  const linearCalls = harness.renderCalls.slice(firstLinearCopyCall)
  const capture = linearCalls.find(call => call.scene === fixture.scene)?.target
  if (!(capture instanceof RenderTarget)) {
    throw new Error('Expected an intermediate linear render target.')
  }
  expect(capture.texture.colorSpace).toBe(LinearSRGBColorSpace)
  expect(capture.texture.type).toBe(HalfFloatType)
  expect(linearCalls.filter(call => call.scene !== fixture.scene).length).toBe(1)
  expect(harness.renderCalls.at(-1)?.target).toBe(null)
  expect(harness.getCurrentTarget()).toBe(null)
  passes.dispose()
})

test('restores the original target when base or linear-copy rendering throws', () => {
  const fixture = createDeferredRenderFixture()
  const harness = createWebGpuRendererHarness(null)
  const passes = createMsfsRenderPasses(
    harness.renderer,
    fixture.scene,
    fixture.camera,
    fixture.root
  )
  passes.setSmaaMode('linear-copy')
  harness.throwOnRenderCall(1)
  let baseError: unknown
  try {
    passes.render()
  } catch (error) {
    baseError = error
  }
  expect(baseError instanceof Error && baseError.message === 'mock render failure').toBe(true)
  expect(harness.getCurrentTarget()).toBe(null)
  passes.dispose()

  const outputFixture = createDeferredRenderFixture()
  const outputHarness = createWebGpuRendererHarness(null)
  const outputPasses = createMsfsRenderPasses(
    outputHarness.renderer,
    outputFixture.scene,
    outputFixture.camera,
    outputFixture.root
  )
  outputPasses.setSmaaMode('linear-copy')
  outputPasses.render()
  const outputScene = outputHarness.renderCalls.at(-1)?.scene
  if (outputScene == null || outputScene === outputFixture.scene) {
    throw new Error('Expected the final output-copy scene.')
  }
  outputHarness.throwOnRenderScene(outputScene)
  let outputError: unknown
  try {
    outputPasses.render()
  } catch (error) {
    outputError = error
  }
  expect(outputError instanceof Error && outputError.message === 'mock render failure').toBe(true)
  expect(outputHarness.getCurrentTarget()).toBe(null)
  outputPasses.dispose()
})

type DeferredRenderFixture = {
  readonly scene: Scene
  readonly camera: PerspectiveCamera
  readonly root: Group
  readonly background: Color
  readonly receiver: Mesh
  readonly receiverMaterial: MeshBasicMaterial
  readonly decal: Mesh
  readonly decalMaterial: InstanceType<typeof MeshStandardNodeMaterial>
}

function createDeferredRenderFixture(): DeferredRenderFixture {
  const scene = new Scene()
  const background = new Color(0xabcdef)
  scene.background = background
  const root = new Group()
  const camera = new PerspectiveCamera(45, 4 / 3, 0.1, 100)
  camera.position.set(0, 0, 5)
  camera.lookAt(0, 0, 0)
  const geometry = new BufferGeometry().setAttribute(
    'position',
    new BufferAttribute(new Float32Array([
      -1, -1, 0,
      1, -1, 0,
      0, 1, 0,
    ]), 3)
  )

  const receiverMaterial = new MeshBasicMaterial()
  receiverMaterial.userData.msfsGBufferWriter = new MeshBasicNodeMaterial()
  const receiver = new Mesh(geometry.clone(), receiverMaterial)

  const decalMaterial = new MeshStandardNodeMaterial()
  decalMaterial.userData.gltfExtensions = {
    ASOBO_material_blend_gbuffer: { baseColorBlendFactor: 1 },
  }
  decalMaterial.userData.msfsGBufferWriter = new MeshBasicNodeMaterial()
  const decal = new Mesh(geometry, decalMaterial)
  decal.userData.msfsBlendGBufferProjectedToReceiver = true
  decal.userData.msfsBlendGBufferReceiver = receiver

  root.add(receiver, decal)
  scene.add(root)
  scene.updateMatrixWorld(true)
  camera.updateMatrixWorld(true)

  return { scene, camera, root, background, receiver, receiverMaterial, decal, decalMaterial }
}

function createWebGpuRendererHarness(screenTarget: RenderTarget | null = new RenderTarget(1, 1)) {
  let currentTarget: RenderTarget | null = screenTarget
  let currentClearColor = new Color(0x123456)
  let currentClearAlpha = 0.25
  let autoClear = false
  let renderCount = 0
  let renderFailureCall: number | null = null
  let renderFailureScene: Scene | null = null
  const screenViewport = new Vector4(2, 3, 100, 80)
  const screenScissor = new Vector4(10, 12, 60, 40)
  const renderCalls: Array<{
    readonly target: RenderTarget | null
    readonly scene: Scene
    readonly autoClear: boolean
    readonly background: Scene['background']
    readonly cameraLayersMask: number
    readonly clearColor: number
    readonly clearAlpha: number
  }> = []

  const rendererObject = Object.assign(
    Object.create(WebGPURenderer.prototype) as object,
    {
      backend: { isWebGPUBackend: true },
      _samples: 4,
      getRenderTarget: () => currentTarget,
      getOutputRenderTarget: () => null,
      setRenderTarget: (target: RenderTarget | null) => { currentTarget = target },
      getPixelRatio: () => 2,
      getViewport: (target: Vector4) => target.copy(screenViewport),
      getScissor: (target: Vector4) => target.copy(screenScissor),
      getScissorTest: () => true,
      getClearColor: (target: Color) => target.copy(currentClearColor),
      getClearAlpha: () => currentClearAlpha,
      setClearColor: (color: ColorRepresentation, alpha = 1) => {
        currentClearColor = new Color(color)
        currentClearAlpha = alpha
      },
      getDrawingBufferSize: (target: Vector2) => target.set(640, 360),
      render: (scene: Scene, camera: Camera) => {
        renderCount += 1
        renderCalls.push({
          target: currentTarget,
          scene,
          autoClear,
          background: scene.background,
          cameraLayersMask: camera.layers.mask,
          clearColor: currentClearColor.getHex(),
          clearAlpha: currentClearAlpha,
        })
        if (renderCount === renderFailureCall || scene === renderFailureScene) {
          throw new Error('mock render failure')
        }
      },
    }
  )
  Object.defineProperty(rendererObject, 'autoClear', {
    get: () => autoClear,
    set: (value: boolean) => { autoClear = value },
    configurable: true,
  })

  return {
    renderer: rendererObject as unknown as Parameters<typeof createMsfsRenderPasses>[0],
    screenTarget,
    renderCalls,
    getCurrentTarget: () => currentTarget,
    getClearColor: () => currentClearColor.clone(),
    getClearAlpha: () => currentClearAlpha,
    getAutoClear: () => autoClear,
    throwOnRenderCall: (call: number) => { renderFailureCall = call },
    throwOnRenderScene: (scene: Scene) => { renderFailureScene = scene },
  }
}
