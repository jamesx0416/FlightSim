import { expect, test } from 'bun:test'
import {
  Box3,
  BufferAttribute,
  BufferGeometry,
  DirectionalLight,
  DoubleSide,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  PerspectiveCamera,
  SkinnedMesh,
  Scene,
  Texture,
  Vector3,
  type Material
} from 'three'

import type { AppRenderer } from './createAppRenderer'
import { createAircraftShadows } from './createAircraftShadows'

function createRenderer(): AppRenderer {
  return { shadowMap: { enabled: true } } as unknown as AppRenderer
}

test('fits the directional shadow camera to the model bounds in world space', () => {
  const renderer = createRenderer()
  const scene = new Scene()
  const camera = new PerspectiveCamera()
  const root = new Group()
  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new BufferAttribute(new Float32Array([
    -2, -1, -3,
    2, -1, -3,
    0, 3, 4
  ]), 3))
  root.position.set(7, 4, -5)
  root.add(new Mesh(geometry, new MeshStandardMaterial()))
  scene.add(root)
  const keyLight = new DirectionalLight()
  keyLight.position.set(34, 9, 18)
  scene.add(keyLight)

  createAircraftShadows(renderer, scene, camera, keyLight, root)

  const bounds = new Box3().setFromObject(root)
  const center = bounds.getCenter(new Vector3())
  expect(keyLight.castShadow).toBe(false)
  expect(renderer.shadowMap.enabled).toBe(false)
  expect(keyLight.shadow.mapSize.toArray()).toEqual([4096, 4096])
  expect(keyLight.target.position.distanceTo(center) < 1e-5).toBe(true)
  for (const x of [bounds.min.x, bounds.max.x]) {
    for (const y of [bounds.min.y, bounds.max.y]) {
      for (const z of [bounds.min.z, bounds.max.z]) {
        const point = new Vector3(x, y, z).applyMatrix4(keyLight.shadow.camera.matrixWorldInverse)
        expect(point.x >= keyLight.shadow.camera.left).toBe(true)
        expect(point.x <= keyLight.shadow.camera.right).toBe(true)
        expect(point.y >= keyLight.shadow.camera.bottom).toBe(true)
        expect(point.y <= keyLight.shadow.camera.top).toBe(true)
        expect(-point.z > keyLight.shadow.camera.near).toBe(true)
        expect(-point.z < keyLight.shadow.camera.far).toBe(true)
      }
    }
  }
})

test('recomputes skinned mesh bounds before each shadow-camera fit', () => {
  const renderer = createRenderer()
  const scene = new Scene()
  const camera = new PerspectiveCamera()
  const root = new Group()
  const skinnedMesh = new SkinnedMesh(new BufferGeometry(), new MeshStandardMaterial())
  let computeCount = 0
  skinnedMesh.computeBoundingBox = () => {
    computeCount += 1
    const extent = computeCount === 1 ? 1 : 5
    skinnedMesh.boundingBox = new Box3(
      new Vector3(-extent, -extent, -extent),
      new Vector3(extent, extent, extent)
    )
  }
  root.add(skinnedMesh)
  scene.add(root)
  const keyLight = new DirectionalLight()
  keyLight.position.set(10, 4, 8)
  scene.add(keyLight)

  const shadows = createAircraftShadows(renderer, scene, camera, keyLight, root)
  shadows.setEnabled(true)
  const initialWidth = keyLight.shadow.camera.right - keyLight.shadow.camera.left
  shadows.prepareForFrame()

  expect(computeCount).toBe(2)
  expect(keyLight.shadow.camera.right - keyLight.shadow.camera.left > initialWidth).toBe(true)
})

test('uses shadow-only materials for the first shadow pass when a pass hides a caster', () => {
  const renderer = createRenderer()
  const scene = new Scene()
  const camera = new PerspectiveCamera()
  const root = new Group()
  const sourceMaterial = new MeshStandardMaterial({ alphaTest: 0.4, side: DoubleSide })
  sourceMaterial.alphaMap = new Texture()
  const mesh: Mesh = new Mesh(new BufferGeometry(), sourceMaterial)
  mesh.castShadow = true
  root.add(mesh)
  scene.add(root)
  const keyLight = new DirectionalLight()
  scene.add(keyLight)
  const shadows = createAircraftShadows(renderer, scene, camera, keyLight, root)
  shadows.setEnabled(true)
  const hiddenPlaceholder = new MeshBasicMaterial({ visible: false })

  shadows.prepareForFrame()
  mesh.material = hiddenPlaceholder
  shadows.renderFirstScenePass(() => {
    expect(mesh.material).toBe(hiddenPlaceholder)
    scene.onBeforeRender(renderer as Parameters<Scene['onBeforeRender']>[0], scene, keyLight.shadow.camera, new BufferGeometry(), sourceMaterial, root)
    const shadowMaterial = mesh.material as MeshBasicMaterial & { alphaMap: Texture | null; alphaTest: number }
    expect(shadowMaterial instanceof MeshBasicMaterial).toBe(true)
    expect((shadowMaterial as Material) !== hiddenPlaceholder).toBe(true)
    expect((shadowMaterial as Material) !== sourceMaterial).toBe(true)
    expect(shadowMaterial.alphaMap).toBe(sourceMaterial.alphaMap)
    expect(shadowMaterial.alphaTest).toBe(sourceMaterial.alphaTest)
    expect(shadowMaterial.side).toBe(sourceMaterial.side)
    expect(shadowMaterial.colorWrite).toBe(false)
    expect(shadowMaterial.depthWrite).toBe(true)
    expect(shadowMaterial.visible).toBe(true)
    scene.onAfterRender(renderer as Parameters<Scene['onAfterRender']>[0], scene, keyLight.shadow.camera, new BufferGeometry(), sourceMaterial, root)
    expect(mesh.material).toBe(hiddenPlaceholder)
  })

  expect(mesh.material).toBe(hiddenPlaceholder)
})



test('disposes cached shadow-only materials', () => {
  const renderer = createRenderer()
  const scene = new Scene()
  const camera = new PerspectiveCamera()
  const root = new Group()
  const mesh = new Mesh(new BufferGeometry(), new MeshStandardMaterial())
  mesh.castShadow = true
  root.add(mesh)
  scene.add(root)
  const keyLight = new DirectionalLight()
  scene.add(keyLight)
  const shadows = createAircraftShadows(renderer, scene, camera, keyLight, root)
  shadows.setEnabled(true)
  shadows.prepareForFrame()
  const shadowMaterials: Material[] = []
  shadows.renderFirstScenePass(() => {
    scene.onBeforeRender(renderer as Parameters<Scene['onBeforeRender']>[0], scene, keyLight.shadow.camera, new BufferGeometry(), mesh.material as Material, root)
    shadowMaterials.push(mesh.material as Material)
    scene.onAfterRender(renderer as Parameters<Scene['onAfterRender']>[0], scene, keyLight.shadow.camera, new BufferGeometry(), mesh.material as Material, root)
  })
  const shadowMaterial = shadowMaterials[0]
  expect(shadowMaterial != null).toBe(true)
  if (shadowMaterial == null) throw new Error('Expected a cached shadow material.')
  let disposed = false
  shadowMaterial.addEventListener('dispose', () => { disposed = true })

  shadows.dispose()

  expect(disposed).toBe(true)
})

test('restores shared caster visibility and scene hooks when the shadow render throws', () => {
  const renderer = createRenderer()
  const scene = new Scene()
  const camera = new PerspectiveCamera()
  const root = new Group()
  const sourceMaterial = new MeshStandardMaterial()
  for (let index = 0; index < 2; index += 1) {
    const mesh = new Mesh(new BufferGeometry(), sourceMaterial)
    mesh.castShadow = true
    root.add(mesh)
  }
  scene.add(root)
  const keyLight = new DirectionalLight()
  scene.add(keyLight)
  const shadows = createAircraftShadows(renderer, scene, camera, keyLight, root)
  shadows.prepareForFrame()
  sourceMaterial.visible = false
  const before = scene.onBeforeRender
  const after = scene.onAfterRender
  let threw = false
  try {
    shadows.renderFirstScenePass(() => {
      scene.onBeforeRender(renderer as Parameters<Scene['onBeforeRender']>[0], scene, keyLight.shadow.camera, new BufferGeometry(), sourceMaterial, root)
      const shadowMaterials = root.children.map(child => (child as Mesh).material)
      expect(shadowMaterials.every(material => material instanceof MeshBasicMaterial && material.visible)).toBe(true)
      expect(sourceMaterial.visible).toBe(false)
      throw new Error('shadow failure')
    })
  } catch {
    threw = true
  }
  expect(threw).toBe(true)
  expect(sourceMaterial.visible).toBe(false)
  expect(scene.onBeforeRender).toBe(before)
  expect(scene.onAfterRender).toBe(after)
  shadows.setEnabled(false)
  expect(keyLight.castShadow).toBe(false)
  expect(renderer.shadowMap.enabled).toBe(false)
  shadows.setEnabled(true)
  expect(keyLight.castShadow).toBe(true)
})
