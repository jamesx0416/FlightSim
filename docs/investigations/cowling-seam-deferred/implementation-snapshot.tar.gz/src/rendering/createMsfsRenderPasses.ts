import {
  BufferAttribute,
  Color,
  DirectionalLight,
  Frustum,
  Matrix4,
  Mesh,
  MeshBasicMaterial,
  SkinnedMesh,
  type Camera,
  type Material,
  type Object3D,
  type Scene
} from 'three'
import { WebGPURenderer } from 'three/webgpu'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

import {
  createMsfsDeferredLightingMaterial,
  getMsfsGBufferWriter,
  usesBlendGBufferColorMaterial,
  usesBlendGBufferMaterial
} from '../msfs/gltf/normalizeMsfsMaterials'
import {
  createAircraftGBuffer,
  supportsAircraftGBuffer
} from './createAircraftGBuffer'
import type { AppRenderer } from './createAppRenderer'
import type { AircraftShadows } from './createAircraftShadows'
import {
  createContactOcclusionControl,
  type ContactOcclusionStatus,
  type ContactOcclusionControl,
} from './contactOcclusion'
import {
  createMsfsHdrOutput,
  type MsfsHdrOutput,
  type MsfsHdrOutputMode
} from './createMsfsHdrOutput'

type MsfsMaterial = Material & {
  depthTest?: boolean
  depthWrite?: boolean
  polygonOffset?: boolean
  userData?: {
    readonly gltfExtensions?: Record<string, unknown>
    readonly msfsBlendGBufferForwardColor?: boolean
  }
}

type MaterialRenderState = {
  readonly visible: boolean
  readonly depthTest: boolean
  readonly depthWrite: boolean
  readonly polygonOffset: boolean
}

type BlendGBufferMesh = Mesh & {
  material: MsfsMaterial
  userData?: {
    readonly msfsBlendGBufferProjectedToReceiver?: boolean
  }
}

export interface MsfsRenderPasses {
  readonly hasBlendGBufferDecals: boolean
  refresh(): void
  setDeferredEnabled(enabled: boolean): void
  setSharedHdrOutputEnabled(enabled: boolean): void
  setContactOcclusionEnabled(enabled: boolean): ContactOcclusionStatus
  getContactOcclusionStatus(): ContactOcclusionStatus
  setSmaaMode(mode: MsfsSmaaMode): MsfsSmaaStatus
  render(): void
  dispose(): void
}

type BaseMsfsRenderPasses = Omit<
  MsfsRenderPasses,
  'setSmaaMode' | 'setContactOcclusionEnabled' | 'getContactOcclusionStatus'
>
type SmaaMsfsRenderPasses = Omit<
  MsfsRenderPasses,
  'setContactOcclusionEnabled' | 'getContactOcclusionStatus'
>

export type MsfsSmaaMode = 'off' | MsfsHdrOutputMode

export interface MsfsSmaaStatus {
  readonly supported: boolean
  readonly mode: MsfsSmaaMode
  readonly ready: boolean
}

export interface MsfsRenderPassOptions {
  readonly sharedHdrOutputEnabled?: boolean
  readonly shadows?: AircraftShadows
  readonly keyLight?: DirectionalLight
  readonly contactOcclusionEnabled?: boolean
  readonly reversedDepthBuffer?: boolean
}

export type MsfsDecalRenderPath = 'regular' | 'deferred' | 'forward'

export function selectMsfsDecalRenderPath(
  hasBlendGBufferDecals: boolean,
  hasDeferredRelationships: boolean,
  supportsDeferred: boolean
): MsfsDecalRenderPath {
  if (!hasBlendGBufferDecals) {
    return 'regular'
  }
  return supportsDeferred && hasDeferredRelationships ? 'deferred' : 'forward'
}

export function canKeepBlendGBufferDecalInForwardScenePass(
  materials: readonly Material[]
): boolean {
  return materials.every(material =>
    material.transparent === true && usesBlendGBufferColorMaterial(material)
  )
}

export function canKeepReceiverlessBlendGBufferMaterialInBasePass(
  material: Material
): boolean {
  return usesBlendGBufferColorMaterial(material) &&
    !usesBlendGBufferDrawOrderMaterial(material as MsfsMaterial)
}

export function hasBlendGBufferReceiver(receiverCount: number): boolean {
  return receiverCount > 0
}

export function createMsfsRenderPasses(
  renderer: AppRenderer,
  scene: Scene,
  camera: Camera,
  root: Object3D,
  options: MsfsRenderPassOptions = {}
): MsfsRenderPasses {
  const contactOcclusion = createContactOcclusionControl(
    renderer,
    scene,
    camera,
    options.keyLight ?? null,
    options.contactOcclusionEnabled ?? false,
    options.reversedDepthBuffer ?? camera.reversedDepth,
    options.shadows?.prepareContactCamera,
  )
  const fallback = createForwardMsfsRenderPasses(
    renderer,
    scene,
    camera,
    root,
    options.shadows,
    contactOcclusion,
  )
  const passes = !hasBlendGBufferMaterials(root) || !supportsAircraftGBuffer(renderer)
    ? fallback
    : createDeferredMsfsRenderPasses(
        renderer,
        scene,
        camera,
        root,
        fallback,
        options.sharedHdrOutputEnabled ?? false,
        options.shadows,
        contactOcclusion
      )
  const smaaPasses = createSmaaCapableRenderPasses(renderer, passes)
  return {
    get hasBlendGBufferDecals() {
      return smaaPasses.hasBlendGBufferDecals
    },
    refresh: () => smaaPasses.refresh(),
    setDeferredEnabled: enabled => smaaPasses.setDeferredEnabled(enabled),
    setSharedHdrOutputEnabled: enabled => smaaPasses.setSharedHdrOutputEnabled(enabled),
    setContactOcclusionEnabled: enabled => contactOcclusion.setEnabled(enabled),
    getContactOcclusionStatus: () => contactOcclusion.getStatus(),
    setSmaaMode: mode => smaaPasses.setSmaaMode(mode),
    render: () => smaaPasses.render(),
    dispose: () => {
      smaaPasses.dispose()
      contactOcclusion.dispose()
    },
  }
}

function createSmaaCapableRenderPasses(
  renderer: AppRenderer,
  passes: BaseMsfsRenderPasses
): SmaaMsfsRenderPasses {
  if (!(renderer instanceof WebGPURenderer)) {
    return {
      get hasBlendGBufferDecals() {
        return passes.hasBlendGBufferDecals
      },
      refresh: () => passes.refresh(),
      setDeferredEnabled: enabled => passes.setDeferredEnabled(enabled),
      setSharedHdrOutputEnabled: enabled => passes.setSharedHdrOutputEnabled(enabled),
      setSmaaMode: () => ({ supported: false, mode: 'off', ready: false }),
      render: () => passes.render(),
      dispose: () => passes.dispose(),
    }
  }

  let mode: MsfsSmaaMode = 'off'
  let outputMode: MsfsHdrOutputMode | null = null
  let output: MsfsHdrOutput | null = null

  const getStatus = (): MsfsSmaaStatus => ({
    supported: true,
    mode,
    ready: mode !== 'smaa' || output?.isSmaaReady() === true,
  })

  return {
    get hasBlendGBufferDecals() {
      return passes.hasBlendGBufferDecals
    },
    refresh: () => passes.refresh(),
    setDeferredEnabled: enabled => passes.setDeferredEnabled(enabled),
    setSharedHdrOutputEnabled: enabled => passes.setSharedHdrOutputEnabled(enabled),
    setSmaaMode: nextMode => {
      if (nextMode !== 'off' && outputMode !== nextMode) {
        const nextOutput = createMsfsHdrOutput(renderer, nextMode)
        output?.dispose()
        output = nextOutput
        outputMode = nextMode
      }
      mode = nextMode
      return getStatus()
    },
    render: () => {
      if (
        mode === 'off' ||
        output == null ||
        (mode === 'smaa' && !output.isSmaaReady()) ||
        renderer.getRenderTarget() != null ||
        renderer.getOutputRenderTarget() != null ||
        renderer.xr?.isPresenting === true
      ) {
        passes.render()
        return
      }

      const originalTarget = renderer.getRenderTarget()
      try {
        renderer.setRenderTarget(output.prepareForFrame())
        passes.render()
        renderer.setRenderTarget(originalTarget)
        output.renderToScreen()
      } finally {
        renderer.setRenderTarget(originalTarget)
      }
    },
    dispose: () => {
      try {
        passes.dispose()
      } finally {
        output?.dispose()
        output = null
        outputMode = null
      }
    },
  }
}

function hasBlendGBufferMaterials(root: Object3D): boolean {
  let found = false
  root.traverse(object => {
    if (found || !(object instanceof Mesh)) {
      return
    }
    const materials = Array.isArray(object.material)
      ? object.material
      : [object.material]
    found = materials.some(usesBlendGBufferMaterial)
  })
  return found
}

type MeshMaterial = Material | Material[]

type DeferredMesh = Mesh & {
  material: MeshMaterial
  userData: Mesh['userData'] & {
    readonly msfsBlendGBufferProjectedToReceiver?: boolean
    readonly msfsBlendGBufferReceiver?: DeferredMesh
    readonly msfsBlendGBufferReceivers?: readonly DeferredMesh[]
    readonly msfsBlendGBufferUsedReceivers?: readonly DeferredMesh[]
    readonly msfsBlendGBufferReceiverGroups?: readonly (DeferredMesh | null)[]
    readonly msfsBlendGBufferFootprintReceivers?: readonly DeferredMesh[]
  }
}

type ResolveBatch = {
  readonly mesh: DeferredMesh
  readonly members: readonly DeferredMesh[]
}

function createDeferredMsfsRenderPasses(
  renderer: WebGPURenderer,
  scene: Scene,
  camera: Camera,
  root: Object3D,
  fallback: BaseMsfsRenderPasses,
  initialSharedHdrOutputEnabled: boolean,
  shadows?: AircraftShadows,
  contactOcclusion?: ContactOcclusionControl,
): BaseMsfsRenderPasses {
  const gBuffer = createAircraftGBuffer(renderer)
  const hiddenMaterial = new MeshBasicMaterial({
    colorWrite: false,
    depthTest: false,
    depthWrite: false,
    visible: false,
  })
  const decals: DeferredMesh[] = []
  const forwardDecals: DeferredMesh[] = []
  const receivers = new Set<DeferredMesh>()
  const footprintReceivers = new Set<DeferredMesh>()
  const decalReceivers = new Map<DeferredMesh, readonly DeferredMesh[]>()
  const receiverFootprintMaterials = new Map<DeferredMesh, MeshMaterial>()
  const writerMaterials = new Map<DeferredMesh, MeshMaterial>()
  const resolveMaterials = new Map<DeferredMesh, MeshMaterial>()
  const resolveBatches: ResolveBatch[] = []
  const sourceMaterials = new Map<DeferredMesh, MeshMaterial>()
  const forwardSourceMaterials = new Map<DeferredMesh, MeshMaterial>()
  const forwardColorMaterials = new Set<Material>()
  const originalForwardDecalLayerMasks = new Map<Mesh, number>()
  const opaqueSceneMaterials = new Set<Material>()
  const transparentSceneMaterials = new Set<Material>()
  const disposableLightingMaterials = new Set<Material>()
  const deferredFrustum = new Frustum()
  const deferredViewProjection = new Matrix4()
  let forwardDecalLayerMask = findLayerMaskOutsideCamera(camera)
  let sharedResolveMaterial: Material | null = null
  let canRenderDeferred = false
  let deferredEnabled = true
  let sharedHdrOutputEnabled = initialSharedHdrOutputEnabled
  let sharedHdrOutput: MsfsHdrOutput | null = null

  const refresh = (): void => {
    fallback.refresh()
    restoreMeshDrawables(originalForwardDecalLayerMasks)
    originalForwardDecalLayerMasks.clear()
    for (const batch of resolveBatches) {
      batch.mesh.removeFromParent()
      batch.mesh.geometry.dispose()
    }
    resolveBatches.length = 0
    for (const material of disposableLightingMaterials) {
      material.dispose()
    }
    decals.length = 0
    forwardDecals.length = 0
    receivers.clear()
    footprintReceivers.clear()
    decalReceivers.clear()
    receiverFootprintMaterials.clear()
    writerMaterials.clear()
    resolveMaterials.clear()
    sourceMaterials.clear()
    forwardSourceMaterials.clear()
    forwardColorMaterials.clear()
    opaqueSceneMaterials.clear()
    transparentSceneMaterials.clear()
    disposableLightingMaterials.clear()
    sharedResolveMaterial = null
    forwardDecalLayerMask = findLayerMaskOutsideCamera(camera)
    canRenderDeferred = false

    if (!deferredEnabled) {
      return
    }

    collectSceneMaterials(scene, opaqueSceneMaterials, transparentSceneMaterials)

    let requiresFullFallback = false
    root.traverse(object => {
      if (!(object instanceof Mesh)) {
        return
      }
      const decal = object as DeferredMesh
      if (isInteriorModelObject(decal)) {
        return
      }
      const decalMaterials = getMaterials(decal.material)
      if (
        decal.userData.msfsBlendGBufferProjectedToReceiver !== true ||
        !decalMaterials.some(usesBlendGBufferMaterial)
      ) {
        return
      }

      const canStayInForwardScenePass =
        canKeepBlendGBufferDecalInForwardScenePass(decalMaterials)
      const rejectRelationship = (): void => {
        if (canStayInForwardScenePass) {
          if (!forwardSourceMaterials.has(decal)) {
            forwardDecals.push(decal)
            forwardSourceMaterials.set(decal, decal.material)
            for (const material of decalMaterials) {
              forwardColorMaterials.add(material)
            }
          }
        } else {
          requiresFullFallback = true
        }
      }
      const relatedReceivers = decal.userData.msfsBlendGBufferUsedReceivers ??
        decal.userData.msfsBlendGBufferReceivers ??
        (decal.userData.msfsBlendGBufferReceiver == null
          ? []
          : [decal.userData.msfsBlendGBufferReceiver])
      const decalWriters = mapMaterials(decal.material, getMsfsGBufferWriter)
      if (!hasBlendGBufferReceiver(relatedReceivers.length) || decalWriters == null) {
        rejectRelationship()
        return
      }
      if (sharedResolveMaterial == null) {
        const sourceMaterial = decalMaterials[0]
        const writer = getMsfsGBufferWriter(sourceMaterial) as (Material & { depthNode?: unknown }) | null
        const lighting = createMsfsDeferredLightingMaterial(sourceMaterial, gBuffer.textures)
        if (writer == null || lighting == null) {
          lighting?.dispose()
          rejectRelationship()
          return
        }
        const resolve = lighting as Material & { depthNode?: unknown }
        contactOcclusion?.registerLightingMaterial(lighting)
        resolve.depthNode = writer.depthNode
        resolve.depthTest = true
        resolve.depthWrite = false
        sharedResolveMaterial = resolve
        disposableLightingMaterials.add(resolve)
      }
      const decalResolve = Array.isArray(decal.material)
        ? decal.material.map(() => sharedResolveMaterial!)
        : sharedResolveMaterial

      const pendingReceiverVariants: Array<{
        readonly receiver: DeferredMesh
        readonly writers: MeshMaterial
      }> = []
      for (const receiver of relatedReceivers) {
        const receiverMaterials = getMaterials(receiver.material)
        if (
          receiverMaterials.some(material =>
            material.transparent === true || usesBlendGBufferMaterial(material)
          )
        ) {
          rejectRelationship()
          return
        }
        const receiverWriters = mapMaterials(receiver.material, getMsfsGBufferWriter)
        if (receiverWriters == null) {
          rejectRelationship()
          return
        }
        pendingReceiverVariants.push({ receiver, writers: receiverWriters })
      }

      decals.push(decal)
      decalReceivers.set(decal, relatedReceivers)
      sourceMaterials.set(decal, decal.material)
      writerMaterials.set(decal, decalWriters)
      resolveMaterials.set(decal, decalResolve)
      for (const variant of pendingReceiverVariants) {
        receivers.add(variant.receiver)
        sourceMaterials.set(variant.receiver, variant.receiver.material)
        writerMaterials.set(variant.receiver, variant.writers)
      }
    })

    if (requiresFullFallback) {
      for (const material of disposableLightingMaterials) {
        material.dispose()
      }
      decals.length = 0
      receivers.clear()
      footprintReceivers.clear()
      decalReceivers.clear()
      receiverFootprintMaterials.clear()
      writerMaterials.clear()
      resolveMaterials.clear()
      sourceMaterials.clear()
      forwardDecals.length = 0
      forwardSourceMaterials.clear()
      forwardColorMaterials.clear()
      disposableLightingMaterials.clear()
      return
    }

    for (const receiver of receivers) {
      const sourceMaterial = sourceMaterials.get(receiver)
      const writer = writerMaterials.get(receiver)
      if (
        sourceMaterial == null ||
        writer == null ||
        Array.isArray(sourceMaterial) ||
        Array.isArray(writer) ||
        !canWriteReceiverGBufferFromProjectedGeometry(sourceMaterial)
      ) {
        continue
      }
      const relatedDecals = decals.filter(decal =>
        decalReceivers.get(decal)?.includes(receiver)
      )
      if (
        relatedDecals.length > 0 &&
        relatedDecals.every(decal =>
          decal.userData.msfsBlendGBufferFootprintReceivers?.includes(receiver) === true
        )
      ) {
        footprintReceivers.add(receiver)
      }
    }

    for (const decal of decals) {
      const groupReceivers = decal.userData.msfsBlendGBufferReceiverGroups
      if (groupReceivers == null || groupReceivers.length === 0) continue
      const materials = groupReceivers.map(receiver => {
        if (receiver == null || !footprintReceivers.has(receiver)) return hiddenMaterial
        const writer = writerMaterials.get(receiver)
        return Array.isArray(writer) || writer == null ? hiddenMaterial : writer
      })
      if (materials.some(material => material !== hiddenMaterial)) {
        receiverFootprintMaterials.set(decal, materials)
      }
    }

    decals.sort((left, right) => left.renderOrder - right.renderOrder)
    if (sharedResolveMaterial != null) {
      createResolveBatches(decals, sharedResolveMaterial, resolveBatches)
    }
    forwardDecals.sort((left, right) => left.renderOrder - right.renderOrder)
    addMeshDrawablesToLayer(
      forwardDecals,
      forwardDecalLayerMask,
      originalForwardDecalLayerMasks
    )
    canRenderDeferred = decals.length > 0 && receivers.size > 0
  }

  refresh()

  return {
    get hasBlendGBufferDecals() {
      return canRenderDeferred || fallback.hasBlendGBufferDecals
    },
    refresh,
    setDeferredEnabled: enabled => {
      if (deferredEnabled === enabled) {
        return
      }
      deferredEnabled = enabled
      refresh()
    },
    setSharedHdrOutputEnabled: enabled => {
      sharedHdrOutputEnabled = enabled
    },
    render: () => {
      if (!deferredEnabled || !canRenderDeferred) {
        fallback.render()
        return
      }

      shadows?.prepareForFrame()
      contactOcclusion?.renderDepthPrepass()
      let firstSceneRender = true
      const renderScene = (): void => {
        if (firstSceneRender) {
          firstSceneRender = false
          if (shadows == null) {
            renderer.render(scene, camera)
          } else {
            shadows.renderFirstScenePass(() => renderer.render(scene, camera))
          }
          return
        }
        renderer.render(scene, camera)
      }

      const originalBackground = scene.background
      const originalAutoClear = renderer.autoClear
      const originalCameraLayerMask = camera.layers.mask
      const originalTarget = renderer.getRenderTarget()
      const useSharedHdrOutput = sharedHdrOutputEnabled &&
        originalTarget == null &&
        renderer.getOutputRenderTarget() == null &&
        renderer.xr?.isPresenting !== true
      const sceneOutputTarget = useSharedHdrOutput
        ? (sharedHdrOutput ??= createMsfsHdrOutput(renderer)).prepareForFrame()
        : originalTarget
      const originalClearColor = renderer.getClearColor(new Color() as never) as unknown as Color
      const originalClearAlpha = renderer.getClearAlpha()
      const originalMaterialState = new Map<MsfsMaterial, MaterialRenderState>()

      try {
        renderer.setRenderTarget(sceneOutputTarget)
        renderer.autoClear = true
        camera.layers.mask = originalCameraLayerMask
        setMeshMaterials(sourceMaterials, hiddenMaterial)
        setMeshMaterialsFor(receivers, sourceMaterials)
        hideMaterials(transparentSceneMaterials, originalMaterialState)
        renderScene()

        deferredFrustum.setFromProjectionMatrix(
          deferredViewProjection.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse),
          camera.coordinateSystem,
          camera.reversedDepth
        )
        const active = collectVisibleDeferredRelationships(
          decals,
          decalReceivers,
          decal =>
            isDeferredMeshVisible(
              decal,
              camera,
              deferredFrustum,
              sourceMaterials.get(decal),
              originalMaterialState
            )
        )

        restoreMaterialRenderState(originalMaterialState.keys(), originalMaterialState)
        if (active.decals.length > 0) {
          gBuffer.resize()
          hideMaterials(opaqueSceneMaterials, originalMaterialState)
          hideMaterials(transparentSceneMaterials, originalMaterialState)
          scene.background = null
          renderer.setClearColor(0x000000, 0)
          renderer.setRenderTarget(gBuffer.renderTarget)
          renderer.autoClear = true
          setMeshMaterials(sourceMaterials, hiddenMaterial)
          setMeshMaterialsFor(
            [...active.receivers].filter(receiver => !footprintReceivers.has(receiver)),
            writerMaterials
          )
          setMeshMaterialsFor(active.decals, receiverFootprintMaterials)
          renderWithFrozenWorldMatrices(renderer, scene, camera)

          configureDeferredDecalWriterDepthTest(active.decals, writerMaterials)
          renderer.autoClear = false
          setMeshMaterials(sourceMaterials, hiddenMaterial)
          setMeshMaterialsFor(active.decals, writerMaterials)
          renderWithFrozenWorldMatrices(renderer, scene, camera)

          renderer.setRenderTarget(sceneOutputTarget)
          renderer.setClearColor(originalClearColor.getHex(), originalClearAlpha)
          setMeshMaterials(sourceMaterials, hiddenMaterial)
          const selectedBatches = selectCompleteResolveBatches(
            active.decals,
            resolveBatches.map(batch => batch.members)
          )
          setMeshMaterialsFor(selectedBatches.unbatched, resolveMaterials)
          for (const batchIndex of selectedBatches.batchIndices) {
            syncResolveBatch(resolveBatches[batchIndex])
          }
          // Resolve batches may have new transforms, so this pass updates world matrices.
          renderer.render(scene, camera)
          hideResolveBatches(resolveBatches)
        }

        restoreMaterialRenderState(originalMaterialState.keys(), originalMaterialState)
        hideMaterials(opaqueSceneMaterials, originalMaterialState)
        renderer.setRenderTarget(sceneOutputTarget)
        renderer.setClearColor(originalClearColor.getHex(), originalClearAlpha)
        scene.background = null
        renderer.autoClear = false
        setMeshMaterials(sourceMaterials, hiddenMaterial)
        setMeshMaterials(forwardSourceMaterials, hiddenMaterial)
        renderWithFrozenWorldMatrices(renderer, scene, camera)

        if (forwardDecals.length > 0) {
          restoreMeshMaterials(forwardSourceMaterials)
          configureBlendGBufferMaterialsForDecalPass(
            forwardColorMaterials,
            originalMaterialState
          )
          camera.layers.mask = forwardDecalLayerMask
          scene.background = null
          renderer.autoClear = false
          renderWithFrozenWorldMatrices(renderer, scene, camera)
        }

        if (useSharedHdrOutput) {
          renderer.autoClear = false
          sharedHdrOutput?.renderToScreen()
        }
      } finally {
        hideResolveBatches(resolveBatches)
        configureDeferredDecalWriterDepthTest(decals, writerMaterials)
        restoreMeshMaterials(forwardSourceMaterials)
        restoreMeshMaterials(sourceMaterials)
        restoreMaterialRenderState(originalMaterialState.keys(), originalMaterialState)
        renderer.setRenderTarget(originalTarget)
        renderer.setClearColor(originalClearColor.getHex(), originalClearAlpha)
        renderer.autoClear = originalAutoClear
        camera.layers.mask = originalCameraLayerMask
        scene.background = originalBackground
      }
    },
    dispose: () => {
      sharedHdrOutput?.dispose()
      sharedHdrOutput = null
      shadows?.dispose()
    },
  }
}

function createResolveBatches(
  decals: readonly DeferredMesh[],
  material: Material,
  output: ResolveBatch[]
): void {
  const remaining = new Set(decals)
  for (const seed of decals) {
    if (!remaining.has(seed)) continue
    const members = decals.filter(candidate =>
      remaining.has(candidate) && canShareResolveBatch(seed, candidate)
    )
    if (members.length < 2) continue
    const geometry = createResolveBatchGeometry(members)
    if (geometry == null || seed.parent == null) {
      geometry?.dispose()
      continue
    }

    const mesh = seed instanceof SkinnedMesh
      ? new SkinnedMesh(geometry, material)
      : new Mesh(geometry, material)
    if (mesh instanceof SkinnedMesh && seed instanceof SkinnedMesh) {
      mesh.skeleton = seed.skeleton
      mesh.bindMatrix.copy(seed.bindMatrix)
      mesh.bindMatrixInverse.copy(seed.bindMatrixInverse)
    }
    mesh.matrixAutoUpdate = false
    mesh.receiveShadow = seed.receiveShadow
    mesh.matrix.copy(seed.matrix)
    mesh.layers.mask = seed.layers.mask
    mesh.frustumCulled = false
    mesh.visible = false
    seed.parent.add(mesh)
    output.push({ mesh: mesh as DeferredMesh, members })
    for (const member of members) remaining.delete(member)
  }
}

function canShareResolveBatch(left: DeferredMesh, right: DeferredMesh): boolean {
  if (left.receiveShadow !== right.receiveShadow) return false
  if (
    left.parent !== right.parent ||
    left.geometry.index != null ||
    right.geometry.index != null ||
    Object.keys(left.geometry.morphAttributes).length > 0 ||
    Object.keys(right.geometry.morphAttributes).length > 0
  ) {
    return false
  }
  left.updateMatrix()
  right.updateMatrix()
  if (!left.matrix.equals(right.matrix) || left.layers.mask !== right.layers.mask) {
    return false
  }
  if (left instanceof SkinnedMesh || right instanceof SkinnedMesh) {
    return left instanceof SkinnedMesh &&
      right instanceof SkinnedMesh &&
      left.bindMatrix.equals(right.bindMatrix) &&
      left.bindMatrixInverse.equals(right.bindMatrixInverse) &&
      left.skeleton.bones.length === right.skeleton.bones.length &&
      left.skeleton.bones.every((bone, index) => bone === right.skeleton.bones[index])
  }
  return true
}

function createResolveBatchGeometry(members: readonly DeferredMesh[]) {
  const clones = members.map(member => {
    const clone = member.geometry.clone()
    const skinIndex = clone.getAttribute('skinIndex')
    if (skinIndex != null && !(skinIndex.array instanceof Uint32Array)) {
      clone.setAttribute(
        'skinIndex',
        new BufferAttribute(new Uint32Array(skinIndex.array), skinIndex.itemSize, skinIndex.normalized)
      )
    }
    return clone
  })
  const merged = mergeGeometries(clones, false)
  for (const clone of clones) clone.dispose()
  return merged
}

function syncResolveBatch(batch: ResolveBatch): void {
  const source = batch.members[0]
  if (source == null || !batch.members.every(member => canShareResolveBatch(source, member))) {
    return
  }
  source.updateMatrix()
  batch.mesh.matrix.copy(source.matrix)
  batch.mesh.matrixWorldNeedsUpdate = true
  batch.mesh.visible = true
}

function hideResolveBatches(batches: readonly ResolveBatch[]): void {
  for (const batch of batches) batch.mesh.visible = false
}

export function selectCompleteResolveBatches<T>(
  active: readonly T[],
  batches: readonly (readonly T[])[]
): { readonly batchIndices: number[]; readonly unbatched: T[] } {
  const remaining = new Set(active)
  const batchIndices: number[] = []
  for (let index = 0; index < batches.length; index += 1) {
    const batch = batches[index]
    if (batch.length < 2 || !batch.every(member => remaining.has(member))) continue
    batchIndices.push(index)
    for (const member of batch) remaining.delete(member)
  }
  return { batchIndices, unbatched: [...remaining] }
}

export function canWriteReceiverGBufferFromProjectedGeometry(material: Material): boolean {
  const source = material as Material & {
    alphaHash?: boolean
    alphaMap?: unknown
    aoMap?: unknown
    bumpMap?: unknown
    colorNode?: unknown
    displacementMap?: unknown
    emissiveMap?: unknown
    emissiveNode?: unknown
    map?: unknown
    metalnessMap?: unknown
    metalnessNode?: unknown
    normalMap?: unknown
    normalNode?: unknown
    opacityNode?: unknown
    roughnessMap?: unknown
    roughnessNode?: unknown
    aoNode?: unknown
    vertexColors?: boolean
  }
  return source.transparent !== true &&
    source.alphaHash !== true &&
    (source.alphaTest ?? 0) === 0 &&
    source.vertexColors !== true &&
    source.alphaMap == null &&
    source.aoMap == null &&
    source.bumpMap == null &&
    source.displacementMap == null &&
    source.emissiveMap == null &&
    source.map == null &&
    source.metalnessMap == null &&
    source.normalMap == null &&
    source.roughnessMap == null &&
    source.colorNode == null &&
    source.opacityNode == null &&
    source.emissiveNode == null &&
    source.roughnessNode == null &&
    source.metalnessNode == null &&
    source.aoNode == null &&
    source.normalNode == null
}

export function collectVisibleDeferredRelationships<T>(
  decals: readonly T[],
  receiversByDecal: ReadonlyMap<T, readonly T[]>,
  isVisible: (decal: T) => boolean
): { readonly decals: T[]; readonly receivers: Set<T> } {
  const visibleDecals: T[] = []
  const visibleReceivers = new Set<T>()
  for (const decal of decals) {
    if (!isVisible(decal)) continue
    visibleDecals.push(decal)
    for (const receiver of receiversByDecal.get(decal) ?? []) {
      visibleReceivers.add(receiver)
    }
  }
  return { decals: visibleDecals, receivers: visibleReceivers }
}

function isDeferredMeshVisible(
  mesh: DeferredMesh,
  camera: Camera,
  frustum: Frustum,
  sourceMaterial: MeshMaterial | undefined,
  originalMaterialState: ReadonlyMap<MsfsMaterial, MaterialRenderState>
): boolean {
  for (let current: Object3D | null = mesh; current != null; current = current.parent) {
    if (!current.visible) return false
  }
  if (!mesh.layers.test(camera.layers)) return false
  if (
    sourceMaterial != null &&
    !getMaterials(sourceMaterial).some(material =>
      originalMaterialState.get(material as MsfsMaterial)?.visible ?? material.visible
    )
  ) {
    return false
  }
  return mesh.frustumCulled === false || frustum.intersectsObject(mesh)
}

function collectSceneMaterials(
  scene: Scene,
  opaque: Set<Material>,
  transparent: Set<Material>
): void {
  scene.traverse(object => {
    const material = (object as { readonly material?: MeshMaterial }).material
    if (material == null) {
      return
    }
    for (const item of getMaterials(material)) {
      ;(item.transparent === true ? transparent : opaque).add(item)
    }
  })
}

function isInteriorModelObject(object: Object3D): boolean {
  for (let current: Object3D | null = object; current != null; current = current.parent) {
    if (current.userData.msfsModelKind === 'interior') {
      return true
    }
  }
  return false
}

function mapMaterials(
  material: MeshMaterial,
  map: (material: Material) => Material | null
): MeshMaterial | null {
  if (Array.isArray(material)) {
    const mapped = material.map(map)
    return mapped.some(item => item == null) ? null : mapped as Material[]
  }
  return map(material)
}

function getMaterials(material: MeshMaterial): Material[] {
  return Array.isArray(material) ? material : [material]
}

function setMeshMaterials(
  sourceMaterials: ReadonlyMap<DeferredMesh, MeshMaterial>,
  material: Material
): void {
  for (const mesh of sourceMaterials.keys()) {
    mesh.material = Array.isArray(sourceMaterials.get(mesh))
      ? getMaterials(sourceMaterials.get(mesh) as MeshMaterial).map(() => material)
      : material
  }
}

function setMeshMaterialsFor(
  meshes: Iterable<DeferredMesh>,
  materials: ReadonlyMap<DeferredMesh, MeshMaterial>
): void {
  for (const mesh of meshes) {
    const material = materials.get(mesh)
    if (material != null) {
      mesh.material = material
    }
  }
}

function configureDeferredDecalWriterDepthTest(
  decals: Iterable<DeferredMesh>,
  materials: ReadonlyMap<DeferredMesh, MeshMaterial>
): void {
  for (const decal of decals) {
    const material = materials.get(decal)
    if (material == null) {
      continue
    }
    for (const writer of getMaterials(material)) {
      writer.depthTest = true
    }
  }
}

function restoreMeshMaterials(
  sourceMaterials: ReadonlyMap<DeferredMesh, MeshMaterial>
): void {
  for (const [mesh, material] of sourceMaterials) {
    mesh.material = material
  }
}

function renderWithFrozenWorldMatrices(
  renderer: Pick<AppRenderer, 'render'>,
  scene: Scene,
  camera: Camera
): void {
  const sceneMatrixWorldAutoUpdate = scene.matrixWorldAutoUpdate
  const cameraMatrixWorldAutoUpdate = camera.matrixWorldAutoUpdate
  scene.matrixWorldAutoUpdate = false
  camera.matrixWorldAutoUpdate = false
  try {
    renderer.render(scene, camera)
  } finally {
    scene.matrixWorldAutoUpdate = sceneMatrixWorldAutoUpdate
    camera.matrixWorldAutoUpdate = cameraMatrixWorldAutoUpdate
  }
}

function createForwardMsfsRenderPasses(
  renderer: AppRenderer,
  scene: Scene,
  camera: Camera,
  root: Object3D,
  shadows?: AircraftShadows,
  contactOcclusion?: ContactOcclusionControl
): BaseMsfsRenderPasses {
  const blendMeshes: BlendGBufferMesh[] = []
  const decalBlendMeshes: BlendGBufferMesh[] = []
  const hiddenBlendMaterials = new Set<Material>()
  const colorBlendMaterials = new Set<Material>()
  const componentOnlyBlendMaterials = new Set<Material>()
  const nonBlendMaterialsOnBlendMeshes = new Set<Material>()
  const originalBlendMeshLayerMasks = new Map<Mesh, number>()
  let decalLayerMask = findLayerMaskOutsideCamera(camera)

  const refresh = (): void => {
    restoreMeshDrawables(originalBlendMeshLayerMasks)
    originalBlendMeshLayerMasks.clear()
    blendMeshes.length = 0
    decalBlendMeshes.length = 0
    hiddenBlendMaterials.clear()
    colorBlendMaterials.clear()
    componentOnlyBlendMaterials.clear()
    nonBlendMaterialsOnBlendMeshes.clear()
    decalLayerMask = findLayerMaskOutsideCamera(camera)

    root.traverse(object => {
      if (!(object instanceof Mesh)) {
        return
      }

      const materials = Array.isArray(object.material)
        ? object.material
        : object.material != null
          ? [object.material]
          : []
      if (materials.some(material => usesBlendGBufferMaterial(material as MsfsMaterial))) {
        const blendMesh = object as BlendGBufferMesh
        blendMeshes.push(blendMesh)
        const isProjectedDecal =
          blendMesh.userData?.msfsBlendGBufferProjectedToReceiver === true
        let hasForwardColor = false
        for (const material of materials) {
          if (usesBlendGBufferMaterial(material as MsfsMaterial)) {
            const isColorBlendMaterial = usesBlendGBufferColorMaterial(material as MsfsMaterial)
            if (isProjectedDecal && isColorBlendMaterial) {
              hiddenBlendMaterials.add(material)
              colorBlendMaterials.add(material)
              hasForwardColor = true
            } else if (!canKeepReceiverlessBlendGBufferMaterialInBasePass(material)) {
              hiddenBlendMaterials.add(material)
              componentOnlyBlendMaterials.add(material)
            }
          } else {
            nonBlendMaterialsOnBlendMeshes.add(material)
          }
        }
        if (hasForwardColor) {
          decalBlendMeshes.push(blendMesh)
        }
      }
    })

    addMeshDrawablesToLayer(
      decalBlendMeshes,
      decalLayerMask,
      originalBlendMeshLayerMasks
    )
  }

  refresh()

  return {
    get hasBlendGBufferDecals() {
      return decalBlendMeshes.length > 0
    },
    refresh,
    setDeferredEnabled: () => {},
    setSharedHdrOutputEnabled: () => {},
    render: () => {
      shadows?.prepareForFrame()
      contactOcclusion?.renderDepthPrepass()
      let firstSceneRender = true
      const renderScene = (): void => {
        if (firstSceneRender) {
          firstSceneRender = false
          if (shadows == null) {
            renderer.render(scene, camera)
          } else {
            shadows.renderFirstScenePass(() => renderer.render(scene, camera))
          }
          return
        }
        renderer.render(scene, camera)
      }

      if (blendMeshes.length === 0) {
        renderScene()
        return
      }

      const originalBackground = scene.background
      const originalAutoClear = renderer.autoClear
      const originalCameraLayerMask = camera.layers.mask
      const originalMaterialState = new Map<MsfsMaterial, MaterialRenderState>()

      try {
        renderer.autoClear = true
        hideMaterials(hiddenBlendMaterials, originalMaterialState)
        renderScene()

        restoreMaterialRenderState(colorBlendMaterials, originalMaterialState)
        hideMaterials(componentOnlyBlendMaterials, originalMaterialState)
        hideMaterials(nonBlendMaterialsOnBlendMeshes, originalMaterialState)
        configureBlendGBufferMaterialsForDecalPass(
          colorBlendMaterials,
          originalMaterialState
        )
        camera.layers.mask = decalLayerMask
        scene.background = null
        renderer.autoClear = false
        renderer.render(scene, camera)
      } finally {
        restoreMaterialRenderState(
          originalMaterialState.keys(),
          originalMaterialState
        )
        camera.layers.mask = originalCameraLayerMask
        scene.background = originalBackground
        renderer.autoClear = originalAutoClear
      }
    },
    dispose: () => {
      shadows?.dispose()
    },
  }
}

function addMeshDrawablesToLayer(
  meshes: readonly Mesh[],
  layerMask: number,
  originalMeshLayerMasks: Map<Mesh, number>
): void {
  for (const mesh of meshes) {
    originalMeshLayerMasks.set(mesh, mesh.layers.mask)
    mesh.layers.mask |= layerMask
  }
}

function restoreMeshDrawables(originalMeshLayerMasks: Map<Mesh, number>): void {
  for (const [mesh, layerMask] of originalMeshLayerMasks) {
    mesh.layers.mask = layerMask
  }
}

function hideMaterials(
  materials: Iterable<Material>,
  originalMaterialState: Map<MsfsMaterial, MaterialRenderState>
): void {
  for (const material of materials) {
    preserveMaterialRenderState(material as MsfsMaterial, originalMaterialState)
    material.visible = false
  }
}

function usesBlendGBufferDrawOrderMaterial(material: MsfsMaterial): boolean {
  return material.userData?.gltfExtensions?.ASOBO_material_draw_order != null
}

export function configureBlendGBufferMaterialsForDecalPass(
  materials: Iterable<Material>,
  originalMaterialState: Map<MsfsMaterial, MaterialRenderState>
): void {
  for (const material of materials) {
    const msfsMaterial = material as MsfsMaterial
    preserveMaterialRenderState(msfsMaterial, originalMaterialState)
    msfsMaterial.visible = originalMaterialState.get(msfsMaterial)?.visible ?? msfsMaterial.visible
    msfsMaterial.depthTest = true
    msfsMaterial.depthWrite = false
    msfsMaterial.polygonOffset = originalMaterialState.get(msfsMaterial)?.polygonOffset ?? msfsMaterial.polygonOffset ?? false
  }
}

function restoreMaterialRenderState(
  materials: Iterable<Material>,
  originalMaterialState: ReadonlyMap<MsfsMaterial, MaterialRenderState>
): void {
  for (const material of materials) {
    const msfsMaterial = material as MsfsMaterial
    const state = originalMaterialState.get(msfsMaterial)
    if (state != null) {
      msfsMaterial.visible = state.visible
      msfsMaterial.depthTest = state.depthTest
      msfsMaterial.depthWrite = state.depthWrite
      msfsMaterial.polygonOffset = state.polygonOffset
    }
  }
}

function preserveMaterialRenderState(
  material: MsfsMaterial,
  originalMaterialState: Map<MsfsMaterial, MaterialRenderState>
): void {
  if (originalMaterialState.has(material)) {
    return
  }

  originalMaterialState.set(material, {
    visible: material.visible,
    depthTest: material.depthTest ?? true,
    depthWrite: material.depthWrite ?? true,
    polygonOffset: material.polygonOffset ?? false
  })
}

function findLayerMaskOutsideCamera(camera: Camera): number {
  for (let layer = 0; layer < 32; layer += 1) {
    const layerMask = 1 << layer
    if ((camera.layers.mask & layerMask) === 0) {
      return layerMask
    }
  }

  return 0
}
